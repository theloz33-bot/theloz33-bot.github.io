# Batch Task Manifest

Stage 2 of the pipeline: register one generation task per cut, track it to a downloaded original, and never pay twice for the same cut.

The manifest is the receipt. If a task id is not written down, the task does not exist for the next run — and the next run will order it again.

---

## 1. Two files, two jobs

| File | Role | Rule |
|---|---|---|
| `LUDYTE_VIDEO_TASKS.md` | the **state board**: one row per cut, current state, settings, where the file went | rewritten in place as states change; always complete |
| `out/tasks.txt` | the **append-only log**: what was downloaded, when, and what the probe said | never edited, never reordered, only appended |

A run that finds both files missing is a first run: create them from the templates below before submitting anything.

## 2. `LUDYTE_VIDEO_TASKS.md` schema

```markdown
# Video tasks — {project}

Run lock: model {model} · 768p · {aspect} · {5|10}s · count {n} · quality {tier}
Registered: {YYYY-MM-DD HH:MM} · Runtime target: {T}s = {frames} frames @ {fps} fps

| Cut | Shot | Task | State | Seconds | Mouth | Settings | Downloaded | Probe | Notes |
|---|---|---|---|---|---|---|---|---|---|
| S01 | COLD_OPEN | https://ludyte.com/tasks/{task-uuid} | DONE | 5 | no-lip | 768p, 16:9, x1, Best | raw/S01_COLD_OPEN.mp4 | 1366x768 24fps 5.00s no-audio | wisp of steam, usable |
| S02 | HERO_LOCK | https://ludyte.com/tasks/{task-uuid} | RUNNING | 5 | no-lip | 768p, 16:9, x1, Best | — | — | registered 09:12 |
| S06 | CHORUS_A | — | PLANNED | 10 | performance | — | — | — | vocal stem attached |
| S07 | PLACE_JUMP | — | HELD | 5 | no-lip | — | — | — | awaiting a decision on shot list |
```

`Mouth` is `no-lip` or `performance`. A performance cut means the prompt carries one sung line and a lead vocal stem was attached; stage 3 keeps its audio only if that was intended and mutes it otherwise. A no-lip cut must arrive without audio.

`768p` is the default resolution tier and the header says so. It goes on the header line rather than being assumed: the tier is what every cut in the batch must match, and a batch that quietly mixes tiers is a batch that cannot be cut together. A higher tier (1080p, 2K) is written here only when the owner asked for it before the run started.

**States**

| State | Means | Who can move it |
|---|---|---|
| `PLANNED` | cut exists on the board, no task | a run authorized to generate |
| `REGISTERED` | task accepted by the platform, no progress yet | the platform |
| `RUNNING` | generating | the platform |
| `DONE` | platform finished, not yet downloaded | the run |
| `DOWNLOADED` | original on disk, probed | the run |
| `PASS` | picture accepted for the edit | the reviewer |
| `FAIL` | unusable; kept as evidence, never overwritten | the reviewer |
| `HELD` | deliberately not generated, waiting on a human decision | a human only |

`FAIL` and `HELD` are terminal for an automated run. Clearing either one is a human decision, recorded in `Notes` with the date.

## 3. `out/tasks.txt` format

One line per event, tab-separated, appended in the order it happened:

```
DONE   S01   {task-uuid}   raw/S01_COLD_OPEN.mp4     1366x768 24.00 5.00s  no-audio
DONE   S03   {task-uuid}   raw/S03_MACHINE.mp4       1366x768 24.00 5.00s  no-audio
FAIL   S05   {task-uuid}   fails/S05_ATTEMPT1.mp4    1280x720  24.00 5.00s  no-audio   blur, glyph traces
HELD   S07   —             —                          —         —     —       awaiting shot-list decision
```

Columns: `EVENT  CUT  TASK_ID  PATH  WxH  FPS  DURATION  AUDIO  NOTE`.

Why append-only: a rewrite can silently drop the one line that proves a task was paid for. Append, then read the whole file before acting.

## 4. Registering a task

Before every submit, in this order:

1. **Read the manifest.** If the cut has any state other than `PLANNED`, do not submit.
2. **Check the platform's own task list** for the project. A task can exist without a manifest row (an interrupted run, a retry, another session). Adopt it into the manifest instead of ordering a second one.
3. **Confirm the settings** match the run lock. A mismatched resolution or duration makes the cut unusable next to its neighbours, and the money is spent either way. The lock is 768p unless the owner raised it; a task that will deliver at a higher tier while the lock says 768p is a settings error to fix before submitting, not after.
4. **Submit one cut.** One task, one cut, one take.
5. **Capture immediately**: full task id and URL into the manifest row, state `REGISTERED`, with the date and time. Do this before looking at anything else.

A task id written from memory is not an id. Copy it.

## 5. Watching

| Rule | Why |
|---|---|
| Poll on a schedule of 10–60 minutes | generation takes minutes to tens of minutes; tighter polling buys nothing and costs quota |
| Never idle-wait in a loop | a run that blocks on a timer cannot do anything else |
| Quiet when nothing changed | "still running" every cycle is noise; report state change, completion, or a blocker |
| Re-read the project before each poll | another session may have downloaded, reviewed or re-cut while this one slept |
| Never download twice | check `raw/` and the log for the path before pulling |
| Download via the normal control | originals only; no screen recording, no screenshot, no re-encode of the source |
| Probe on arrival | pixels, fps, duration, audio stream — record what the file is, not what the page claims |
| Set a deadline on any watch | a watch that outlives its deadline is a leak |

### Deadline watch

If a watch is created with an expiry (a delivery date, a credit window, a client review), record it in the manifest header. At expiry the run reports the actual state once, changes nothing, and deletes the watch. It does not regenerate to beat the clock.

## 6. Gating rules

The full list lives in `SKILL.md §2.4`. The ones that protect money:

- **No re-roll, no resubmit, no regenerate** after the first submission of a cut, however bad the result. The cut is reported, once, with evidence.
- **No purchase**: credits, upgrades, seats, higher tiers, second accounts.
- **No cancel** of an in-flight job to free a slot.
- **No deletion** of a task, and no overwrite of `fails/`, `*_lowres`, or any file marked `FAIL` / `PASS`.
- **No settings drift** after the first submit. A new resolution tier is a new run and a new decision — 768p is the default and raising it costs queue time, so it belongs to the owner, not to a run.

## 7. Duplicate billing, specifically

The way money is lost twice with the same cut:

| Situation | What goes wrong | Guard |
|---|---|---|
| Run interrupted between submit and manifest write | task exists, manifest says PLANNED, next run submits again | adopt from the platform's task list first |
| Two sessions on the same project | both see PLANNED, both submit | manifest row written before anything else; second session re-reads |
| "It looks broken, let me retry" | new task for a cut that might still finish | never retry on appearance — wait for a terminal state |
| Retry with a changed prompt but same cut | two different clips for one slot, one paid for nothing | prompt changes are a human decision, logged |
| Download of the wrong task | two videos on disk, one untracked | filename carries the cut and shot; log carries the id |

## 8. Report format

A batch report is three lines plus evidence, not a story:

```
Batch {project}: {done}/{total} downloaded, {running} running, {failed} failed.
Probe: S01 1366x768 24fps 5.00s · S02 1366x768 24fps 5.00s · ...
Blocker: {cut} — {what the platform shows} — needs a decision on {options}.
```

If nothing changed since the last report, say nothing. If a cut failed, give the fault in picture terms ("1280×720 source, motion blur mid-clip, glyph traces along the left edge"), not in mood terms.

## 9. Handoff to the edit

The edit reads only what is `PASS`. For each accepted cut: path, frames available, and the direction note from the board. A cut that reached the edit in `DOWNLOADED` but not `PASS` is a decision someone skipped — raise it before rendering, because the render will otherwise hide the difference.
