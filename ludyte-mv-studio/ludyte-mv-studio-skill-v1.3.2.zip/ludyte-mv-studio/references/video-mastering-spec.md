# Video Mastering Spec

Stage 3 of the pipeline: the downloaded clips become `v1_visual_master.mp4` — the exact runtime, silent, at the 768p delivery frame by default (1366×768 at 16:9, 768×1366 at 9:16), cut on the approved timeline, with hard cuts, match cuts or crossfades chosen deliberately.

768p is the default because it is the frame the clips were generated at: rendering bigger adds no detail the source has, only render time and file size. A 1080p or 2K master is a separate, deliberately chosen upscale — §6 has the policy and the numbers.

Everything here is arithmetic on frames. Seconds are a display format; frames are the truth.

---

## 1. Runtime and frame math

| Target | 24 fps | 25 fps | 30 fps |
|---|---|---|---|
| 15 s | 360 | 375 | 450 |
| 20 s | 480 | 500 | 600 |
| 30 s | 720 | 750 | 900 |
| 45 s | 1080 | 1125 | 1350 |
| 60 s | 1440 | 1500 | 1800 |

Rules:

- Pick 24 fps for a filmic master, 30 fps only if the source clips are 30 or the platform's delivery asks for it. Mixing is a re-render, not a fix.
- `duration = frames ÷ fps`. A master at 719 frames is not 30 s; it is 29.958 s, and a festival or platform check will say so.
- Cut lengths in frames must be integers: a 2.4 s cut at 25 fps is 60 frames; at 24 fps it is 57.6 — round the plan, not the render.
- Store the target in the production document: `Runtime target: {T}s = {frames} frames @ {fps} fps`.

## 2. Normalise every source

Render every cut to the same spec before assembly. Normalising inside the assembly graph is possible but makes a fault hard to trace to its source.

```bash
ffmpeg -y -i "raw/S01_{SHOT}.mp4" -an \
  -vf "scale=1366:768:flags=lanczos:force_original_aspect_ratio=increase,crop=1366:768,fps=24,setsar=1,format=yuv420p" \
  -frames:v 120 \
  -c:v libx264 -crf 14 -preset slow -g 24 -movflags +faststart seg_01.mp4
```

For a vertical film the same block reads `scale=768:1366` / `crop=768:1366`. Every segment carries the one frame the whole film is normalised to — 768p unless the run was explicitly authorised at a higher tier (§6).

| Parameter | Value | Why |
|---|---|---|
| `scale` + `crop` | target size, fill then centre-crop | avoids letterbox bars and distorted faces; crop only up to ~5 % of the frame |
| `flags=lanczos` | — | cleanest upscale of the cheap ones |
| `fps=24` | before any transition filter | converts VFR to CFR at the source of the problem |
| `setsar=1` | — | different SARs make `xfade` blend garbage |
| `format=yuv420p` | — | playback compatibility for every platform |
| `-frames:v N` | exact cut length in frames | the clip is cut by frames, not by seconds |
| `-crf 14 -preset slow` | near-transparent intermediate | each re-encode adds a generation of loss |
| `-g 24` | 1-second GOP | precise seeking and clean joins |
| `-an` | drop all audio | generated speech and music are never part of the master |

Short source: extend the tail rather than slow the clip.

```bash
-vf "...,tpad=stop_mode=clone:stop_duration=0.6"   # holds the last frame
```

Long source: take the frames you need from the right in-point (`-ss` before `-i`, frame-accurate after normalisation).

## 3. Hard cut assembly

```bash
printf "file 'seg_01.mp4'\nfile 'seg_02.mp4'\nfile '...'\nfile 'seg_10.mp4'\n" > concat.txt
ffmpeg -y -f concat -safe 0 -i concat.txt -an \
  -c:v libx264 -crf 14 -preset slow -pix_fmt yuv420p -g 24 -movflags +faststart v1_visual_master.mp4
```

Expected frames: `Σ seg frames`. The concat demuxer refuses mismatched streams; an error here means normalisation was incomplete — go back, do not "fix" it by re-encoding everything into one generation of loss.

Hard cuts are the default and they are not a compromise: a cut at the right frame is sharper than any dissolve.

## 4. Match cuts

A match cut is planned in the board and confirmed here:

- **Position match** — the subject or object sits in the same part of the frame before and after the cut.
- **Direction match** — motion continues in the same screen direction; a leftward move followed by a rightward move reads as a bounce, not a match.
- **Speed match** — similar travel per frame, or the cut reads as a jump in tempo.
- **Shape match** — a circle, a rectangle, a doorway filling the same area.

When a match is planned, the join must be a **hard cut at the exact frame where the matching geometry aligns**. A crossfade over a match dissolves the match into two superimposed frames — the one thing a match cut must never have.

## 5. Crossfades

### 5.1 When a crossfade is right

| Situation | Use | Fade |
|---|---|---|
| Two different places or times | crossfade | 0.25–0.5 s |
| Verse → chorus (a lift, no hard break) | crossfade | 0.2–0.3 s |
| After the bridge, into the last chorus | crossfade | 0.4–0.5 s |
| Section break, time passing, ending | fade through black | 0.3–0.6 s |
| Within the same location, same action | hard cut | — |
| Any match cut | hard cut | — |
| A cut on a beat | hard cut | — |

Two fades in a row on adjacent joins already reads as mush. A longer board usually carries three to five fades; a 30 s film of six cuts is fine with one or two, and hard cuts everywhere is a legitimate plan.

### 5.2 The overlap changes the runtime

A crossfade overlaps the two clips, so the film gets shorter by the fade length at every join:

```
faded runtime = Σ cut lengths − (N − 1) × D
```

To land on T with N cuts and fade D:

```
Σ cut lengths = T + (N − 1) × D
```

Compensate by **lengthening the cuts** — spread the extra frames across the shots that can hold them (a lock-off can hold six frames; a whip pan cannot) — **before** rendering. Do not compensate by:

- stretching the last clip (visible slow motion),
- adding a freeze frame at the end (reads as a stall),
- shortening the music (this is a picture job),
- accepting a shorter film and calling it "about the target" (it is not the target).

Only the fades that actually exist count. On a film with hard cuts at some joins and fades at others — the normal case — the formula is a sum over the faded joins, not a product over all of them:

```
Σ cut lengths   = T + Σ D_k              (k runs over the joins that fade; a hard cut adds 0)
offset_k        = (Σ(first k clip frames) − Σ(j≤k) D_j_frames) ÷ fps
```

Worked example — six cuts, T = 30 s = 720 frames @ 24 fps, D = 6 frames on three of the five joins:

```
total overlap      = 3 × 6 = 18 frames
Σ cut frames       = 720 + 18 = 738 frames (30.750 s)
final master       = 738 − 18 = 720 frames = 30.000 s
```

Five cuts keep their 120 frames (5 s); the chorus cut is generated at 10 s (240 frames) and trimmed to 138 frames (5.75 s) to carry the overlap. Decide per cut which part of the take is used — a lock-off can lose forty frames without anyone noticing, a fast walk cannot — and keep cut 01 and the last cut at their full length if they carry the opening and the ending.

That plan generates 840 frames (35 s) for a 720-frame film. The overage is what a dissolve costs when the board already sums to the runtime, and it is worth knowing before generation starts: if no beat can spare the frames and no cut should be a 10 s job, the film is a hard-cut film — do not pay for a longer clip to buy six frames of dissolve.

### 5.3 The `xfade` graph

`xfade` takes two video streams and starts the second one at `offset` seconds into the first. For clips `a` then `b` with fade `D`:

```
offset = a_duration − D
output = a_duration + b_duration − D
```

Chained over N clips, the offset of join *k* is measured on the accumulated output, and only the fades before it are subtracted:

```
offset_k = Σ(first k clip lengths) − Σ(j ≤ k) D_j      # D_j = 0 at a hard-cut join
```
With a fade on every join this reduces to `Σ(first k) − k × D`, which is the three-clip example below.

Frame-exact: with integer frame lengths and integer fade frames,

```
offset_k = (Σ(first k clip frames) − k × D_frames) ÷ fps
```

Graph for three clips of 120 frames at 24 fps with a 6-frame fade on both joins — overlaps 0.25 s, offsets 114 and 228 frames = 4.75 s and 9.50 s, output 348 frames = 14.5 s:

Inputs are the normalised `seg_*.mp4` from §2; the `scale`/`format` in the graph is a guard against one badly prepared file, not a substitute for §2.

```bash
ffmpeg -y -i seg_01.mp4 -i seg_02.mp4 -i seg_03.mp4 -filter_complex \
"[0:v]fps=24,scale=1366:768,setsar=1,format=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[v0];\
 [1:v]fps=24,scale=1366:768,setsar=1,format=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[v1];\
 [2:v]fps=24,scale=1366:768,setsar=1,format=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[v2];\
 [v0][v1]xfade=transition=fade:duration=0.25:offset=4.75[o1];\
 [o1][v2]xfade=transition=fade:duration=0.25:offset=9.5[o2]" \
 -map "[o2]" -an -fps_mode cfr -r 24 \
 -c:v libx264 -crf 14 -preset slow -pix_fmt yuv420p -g 24 -movflags +faststart out.mp4
```

Generator for the whole chain, so no offset is typed by hand (Python 3, stdlib only):

```python
import sys
frames = [120, 120, 120]          # per-cut frames, in timeline order
fades  = [6, 0]                   # fade frames per join; 0 = a hard cut at that join
fps = 24
if len(fades) != len(frames) - 1:
    sys.exit("one fade value per join")
if max(fades) * 2 >= min(frames):
    sys.exit("fade too long for the shortest cut")
parts = [f"[{i}:v]fps={fps},scale=1366:768,setsar=1,format=yuv420p,"
         f"settb=AVTB,setpts=PTS-STARTPTS[v{i}]" for i in range(len(frames))]
prev, acc, overlap = "[v0]", 0, 0
for k, f in enumerate(fades, start=1):
    acc += frames[k - 1]
    overlap += f
    off = (acc - overlap) / fps
    out = f"[x{k}]"
    if f == 0:
        parts.append(f"{prev}[v{k}]concat=n=2:v=1:a=0{out}")
    else:
        parts.append(f"{prev}[v{k}]xfade=transition=fade:duration={f/fps:.6f}:offset={off:.6f}{out}")
    prev = out
total = sum(frames) - overlap
print(";".join(parts))
print(f"# expected frames: {total}  ({total / fps:.3f}s)", file=sys.stderr)
```

Choose `transition=` from `fade`, `dissolve`, `fadeblack`, `fadewhite`, `smoothleft`, `smoothup`, `circleopen`, `hblur`. For a music film, `fade`, `fadeblack` and — sparingly — `smoothleft` are the whole vocabulary. Wipes, circles and `pixelize` read as a slide deck.

### 5.4 Preventing stutter and dropped frames at the join

| Cause | Symptom | Guard |
|---|---|---|
| Mixed fps sources | a repeat or skip exactly at the fade | `fps=24` on every input before `xfade` |
| Mixed resolution / SAR / pix_fmt | error, or a smear for one frame | normalise first; set `settb=AVTB` |
| VFR source | drift that grows across joins | CFR conversion at input, `-fps_mode cfr` at output |
| Offset landing between frames | a one-frame hitch at the fade's start | integer fade frames; offsets in exact frame fractions |
| Fade longer than the shorter clip | error, or a freezeframe blend | `D ≤ 25 %` of the shorter cut; check before rendering |
| Re-encoding a faded intermediate | accumulation blur | one graph, one encode |
| `-shortest` with transitions | truncated tail | drop it; trust the computed offsets |
| Wrong timebase after `concat` of `xfade` output | stutter on playback only | verify with `ffprobe`, not with the preview player |

Verification at each join: extract the four frames spanning the fade (`fade_start−1`, `fade_start`, `fade_end`, `fade_end+1`) and check motion, not just presence.

```bash
ffmpeg -y -ss 4.708333 -i master.mp4 -frames:v 4 -vf "scale=960:-2" join_01_%02d.png
```

## 6. Resolution policy — 768p default, 1080p/2K on request

| Tier | Size | When |
|---|---|---|
| **768p (16:9)** | **1366×768** | **the default: generation, stills, run lock and the v1/v2 master** |
| **768p (9:16)** | **768×1366** | **the default for vertical** |
| Full HD (upscale) | 1920×1080 | only when the owner asks for a 1080p delivery; labelled upscaled |
| 2K (upscale) | 2560×1440 / 1440×2560 | only when the owner asks for a 2K delivery; labelled upscaled |

Rules:

- **Nothing generates above 768p by default.** A higher generation tier is slower in the queue and costs more per task for picture the 768p master cannot show. Raising it is the owner's decision, recorded as a new run lock, never a mid-run change.
- **The master renders at the generation tier.** A 768p generation gets a 768p master; upscaling it to 2K changes the file size and nothing else, and calling that a "2K master" is the one lie this section exists to prevent. When the owner wants 1080p or 2K anyway, render it as a separate file with `scale=2560:1440:flags=lanczos` (or `scale=1920:1080`), keep the 768p master beside it, and name the upscale in the delivery note.
- **One 768-class frame for the whole film.** If the platform's own 768p tier comes back as 1280×768, 1280×720 or another 768-class frame, use the probe's frame, normalise every segment to it (§2), and write it in the run lock. Never mix two frames in one master.
- A cut that arrived smaller than the delivery frame (a 480p or 720p retry, a mobile download) is described by its source resolution in the note. Either accept it and say so, or report it for an owner decision — the mix is never silently averaged away.
- Upscaling by more than ×1.5 does not add detail; it adds softness and file size. Deliver at the tier the footage actually supports and say why.

## 7. Silent master

- Every encode carries `-an`. Generated audio — speech, room tone, a model's idea of music — never ships.
- Verify: `ffprobe -select_streams a` returns nothing.
- The delivery note says "silent visual master" in those words. It is not a mix, not a master with music, and not ready for release without stage 4 or the owner's own audio pass.

## 8. QC on the file

```bash
ffprobe -v error -count_frames -select_streams v:0 \
  -show_entries stream=codec_name,width,height,r_frame_rate,pix_fmt,sample_aspect_ratio,nb_read_frames,duration \
  -show_entries format=duration,size -of json v1_visual_master.mp4
```

| Check | Pass condition |
|---|---|
| Frame count | equals the plan exactly (±0) |
| Frame rate | exactly the planned rate (`24/1`) |
| Duration | frames ÷ fps, within one frame of the container's `format.duration` |
| Resolution | 1366×768 or 768×1366 — the 768p frame, or the declared upscale tier — on every frame |
| Pixel format | `yuv420p`, SAR `1:1` |
| Audio streams | none |
| Order | cut 01 first, the approved order after it, the last frame belonging to the last cut |
| Joins | no black frame unless planned, no freeze, no two identical frames in a row at a fade |
| Motion | the first and last second of each cut show the intended movement, not a still |
| Text | no lettering anywhere in the picture |

Report the numbers, not the impression. "720 frames, 24/1 fps, 1366×768, no audio, 30.000 s" is a QC pass. "Looks good" is not.

## 9. Defect triage

| Fault | Action |
|---|---|
| Source below the delivery tier | normalise up to the 768p frame and name the cut's real source resolution in the note |
| Blur or smear inside a cut | report; the cut needs a replacement decision, not a filter |
| Generated text or glyph traces | report with the frame; never paint over it silently |
| Wrong subject or wardrobe across cuts | report; this is a generation fault, not an edit fault |
| Cut too short by a few frames | hold the tail (`tpad`) and note it |
| Cut too short by seconds | the timeline is wrong — report, do not stretch |
| Missing cut | the film is not finished; report the gap and stop |
| Wrong fps or VFR master | re-render from the normalised segments |
| Audio present | re-encode with `-an` |

Nothing on this list is fixed by claiming it is fine.

## 10. Delivery

```
out/v1_visual_master.mp4
out/master_report.md      # timeline, per-cut source and frames, probe numbers, defects, what is not verified
```

Filename convention: `{project}_v1_visual_{T}s_{fps}fps_{WxH}.mp4` is easier to keep apart once a lyric master exists beside it. Keep `v1` in the name; stage 4 builds `v2` from it and the two must never be confused.

The report states, in plain terms: exact runtime and frame count, each cut's source file, which cuts were upscaled, which defects are visible and where, and what was **not** verified (no visual review of a cut, a missing reference, an unconfirmed identity match). The owner can then decide about a re-cut or a regeneration — that decision is theirs, and it needs the real state to be made.
