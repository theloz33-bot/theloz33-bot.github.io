# Lyric Subtitle Spec

Stage 4 of the pipeline: Korean, English or bilingual lyric subtitles laid onto the finished `v1_visual_master.mp4`, producing `v2_lyric_master.mp4` with the owner's own track.

Lyrics are the one part of the film the audience reads word for word. A cut can be beautiful and a single mis-timed line ruins it.

Two masters, in order:

| File | Content | Audio | Purpose |
|---|---|---|---|
| `v1_visual_master.mp4` | picture only, no text | none | the edit that gets approved; also the clean master for a version without lyrics |
| `v2_lyric_master.mp4` | v1 + burned subtitles | none, or the owner's track | the delivery version |

Never burn onto a draft. A text layer hides picture faults, and every later picture change costs another full render.

---

## 1. The lyric sheet

One file per language first, before any timing:

```
subs/lyrics_ko.txt     # sung language, as the artist wrote it
subs/lyrics_en.txt     # translation, if the film is bilingual
```

- The sung language comes from the artist's own text. No corrections to spelling or line order — if something looks wrong, ask, do not silently fix a lyric.
- A translation the artist did not supply is marked `translation — not approved` in the report and on the cue discussion, never presented as the artist's words. Unapproved translations still get burned only if the owner asked for them; otherwise they wait.
- Keep the section markers (`[Verse 1]`) in the sheet as comments, not as cues.
- Ad-libs, repeats, and backing vocals: include only if audible and meaningful. A cue for every "oh" is noise.

## 2. Timing

### 2.0 A first pass before typing timestamps

Typing cues from a blank sheet is the slowest and least accurate route. Take a first pass from what the sources already know, then correct it:

- **The tool that made the track** — many generators and DAWs export phrase-level or word-level timings with the lyrics (aligned lyrics, a timestamped sheet, an LRC/SRT sidecar). That is a first pass, not the final timing.
- **A forced alignment of the vocal stem** against the lyric text, where the runtime has one.
- **The stage-1 section map** in the production document, to check that no cue lands in the wrong section: a chorus line opening over the last bar of a verse is the usual symptom of a timing pass that started from nothing.

Then correct by ear at the three anchors of 2.3 and nudge each cue onto the sung line. A first pass that is two frames off is cheap to fix; a hand-typed sheet is where whole lines end up in the wrong bar.

### 2.1 Anchors

Time to the **sung line**, not to the section or the bar.

| Rule | Value | Reason |
|---|---|---|
| Cue enters before the first syllable | 0.10–0.20 s (3–5 frames at 24 fps) | the eye needs a head start on the ear |
| Cue leaves after the last syllable | 0.30–0.60 s, or at the next line's entry if the gap is shorter | a line that vanishes on the last consonant feels clipped |
| Minimum cue | 1.2 s | below this, the line is a flash, not a read |
| Maximum cue | ~6 s | longer and the reader has finished and is waiting |
| Overlap between cues | none, unless a deliberate two-voice moment | overlapping text in one style is unreadable |
| Gap between cues | 2–4 frames | a hard-off/hard-on reads as a flicker |

### 2.2 Reading speed

| Language | Comfortable | Hard limit |
|---|---|---|
| Korean | 12–15 characters/s | 17 |
| English | 12–15 characters/s | 17 |

Over the limit, split the line into two cues at a phrase boundary — do not shrink the type and do not speed the eye up artificially.

### 2.3 Verifying sync

1. Pick three anchors per section: first line, a line after a long instrumental, the last line.
2. Step through the frame where the cue starts and confirm the syllable has not yet begun.
3. Listen once at 1× for the whole film, reading only. Any line that arrives early feels like a spoiler; late feels like a mistake.
4. Check the final cue clears before the picture's last frame.

## 3. Layout: how much text fits

### 3.1 Characters per line

| Aspect | Korean | English |
|---|---|---|
| **16:9 768p (1366×768) — default** | **≤ 20** | **≤ 42** |
| **9:16 768p (768×1366) — default** | **≤ 13** | **≤ 30** |
| 16:9 1080p (1920×1080) — upscale | ≤ 19 | ≤ 40 |
| 16:9 2K (2560×1440) — upscale | ≤ 20 | ≤ 42 |
| 9:16 2K (1440×2560) — upscale | ≤ 13 | ≤ 30 |

Characters per line are a share of the frame, not a pixel count, so the 768p defaults are the same numbers as the upscale tiers. Everything below that *is* in pixels is written for the 768p master, which is the default delivery; the upscaled column gives the multiplier when the owner asked for a 1080p or 2K master.

Two lines per cue, maximum. A third line either covers the picture or shrinks to the point of illegibility.

### 3.2 Korean line-break rules

- Break at a phrase boundary (구 or 절), never inside a word.
- Keep a particle with its noun: `바람이 / 부는 밤` — not `바람 / 이 부는 밤`.
- Do not end a line on a single syllable, a lone particle, or a dangling ending.
- Keep the predicate near its object when the sentence allows it.
- Balance the two lines within about 20 % of each other in length; a 19-character line over a 4-character line looks like an accident.
- Never hyphenate, never break a number from its unit, never break inside an English word or a name.
- Prefer the semantic break over the geometric one: two lines of 10 beats read better than 18 + 2.

### 3.3 English line-break rules

- Break at clause or breath boundaries; keep articles and prepositions with their nouns.
- Avoid ending a line on "the", "a", "of", "to", "and".
- Title-case only if the artist's other materials do; otherwise sentence case.
- Keep contractions as the artist wrote them.

### 3.4 Bilingual stacking

Sung language on the upper line at full size, translation beneath it at ~85 % size and ~90 % opacity. The eye lands on the line it can already hear, and the translation reads as a gloss rather than a second song. In a 9:16 film both lines sit above the app's bottom UI (§4), so the shorter translation is never the line that gets covered.

If the two languages are timed differently (a translation that cannot be squeezed into the same cue), give each its own cue — the layout tolerates it because the sizes differ.

## 4. Safe zones

Platform UI sits on top of the picture: captions toggle, progress bar, action rail, shopping links, handle.

| | 16:9 768p (1366×768) | 9:16 768p (768×1366) |
|---|---|---|
| Bottom margin | ~7 % of height ≈ 54 px | ~17 % of height ≈ 230 px |
| Side margin | ~6 % ≈ 80 px | ~7 % ≈ 54 px |
| Top margin (if text is placed high) | ~8 % ≈ 61 px | ~10 % ≈ 137 px |
| Faces | keep text off eyes and mouth | same |

Scaling to an upscale master: 1080p ×1.41, 2K ×1.87 of these numbers. Burn the layout at the size of the file you are actually burning onto — 2K pixel values pasted onto a 768p master push the text off the frame.

9:16 loses its bottom fifth to the app, not to the film. Text placed at 54 px on a vertical 768p video is under the caption and the button — it is not visible at all.

## 5. Typography

| | 16:9 768p (1366 wide) | 9:16 768p (1366 tall) | 2K upscale (2560) |
|---|---|---|---|
| Size, Korean | 38–42 px | 49–53 px | 72–78 px |
| Size, English | 32–36 px | 42–46 px | 60–66 px |
| Weight | Medium–SemiBold (500–600) | same | same |
| Fill | warm white `#F5F2EA` or pure `#FFFFFF` | same | same |
| Outline | 2 px, near-black `#1C1C1C`, 85 % opacity | 3 px | 4 px |
| Shadow | 1 px down, black 50 % | 2 px | 2 px |
| Box (optional) | 40–60 % black, 7–9 px padding | same | 12–16 px |
| Letter spacing | 0 to +0.5 | 0 | 0 |

Type is a share of the frame height (about 5.2 % Korean, 4.4 % English), so it stays readable at 768p and scales with the master if an upscale is ever asked for. Do not copy 2K pixel sizes onto a 768p burn: 76 px on a 768 px frame is a tenth of the height for one line, and two lines of it eat the shot.

- Fonts that hold Korean: Noto Sans KR, Pretendard, SUIT, Apple SD Gothic Neo. Light and Thin weights break apart over motion; Black is a slab over a face.
- **Ship the font.** Put an OFL-licensed `.ttf`/`.otf` in `fonts/` and pass `fontsdir=` — otherwise libass falls back to a font without Korean glyphs and the render comes back as boxes.
- A hard-edged white line with no outline disappears on a bright frame and cuts a face in half on a dark one. Outline plus shadow is not decoration; it is what makes one style work on every shot.
- Do not animate text (fades, karaoke wipes, bouncing) unless the owner asks. A lyric film earns its motion from the picture.
- Soft entry: `{\fad(120,120)}` on each line. Nothing else.

## 6. Building the files

### 6.1 ASS — the styled source

`subs/lyrics.ass`, with `PlayResX/Y` equal to the master's pixel size — 1366×768 for the default 16:9 master, 768×1366 for 9:16 — so that one font unit is one pixel:

```
[Script Info]
Title: {project} — lyrics
ScriptType: v4.00+
WrapStyle: 2
ScaledBorderAndShadow: yes
PlayResX: 1366
PlayResY: 768
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: KO,Noto Sans KR,40,&H00F5F2EA,&H000000FF,&H101C1C1C,&H80000000,0,0,0,0,100,100,0.5,0,1,2,1,2,80,80,112,1
Style: EN,Noto Sans KR,34,&H00F5F2EA,&H000000FF,&H101C1C1C,&H80000000,0,0,0,0,100,100,0,0,1,2,1,2,80,80,58,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:03.20,0:00:06.90,KO,,0,0,0,,{\fad(120,120)}첫 번째 가사의 한 줄
Dialogue: 0,0:00:03.20,0:00:06.90,EN,,0,0,0,,{\fad(120,120)}the first line of the lyric
Dialogue: 0,0:00:06.95,0:00:10.40,KO,,0,0,0,,{\fad(120,120)}두 번째 줄은 / 숨을 고르고
```

Notes that save a render:

- `WrapStyle: 2` — no automatic wrapping; a break happens only where `\N` is written. Automatic wrapping produces the one-word orphan line nobody wants.
- `MarginV` differs per style so the two languages stack without overlap: the sung line sits at 112, the translation beneath it at 58 (font 40 → the Korean line occupies roughly 112–152 px from the bottom, the English line 58–92). For a 9:16 master at 768×1366, add the safe-zone offset to both: about 288 and 235. On a 2K upscale master the same layout is ×1.87 (210 / 110 with fonts 76 / 64) — change `PlayResX/Y` and the style line together, never one without the other.
- Colours in ASS are `&HAABBGGRR` — alpha first, then blue, green, red. `&H00FFFFFF` is opaque white; `&H80000000` is 50 % black.
- For a semi-transparent box: `BorderStyle=3` with `Outline=7` (the outline value becomes the box padding) and `BackColour=&HA0000000` (about 63 % black).
- `-` at the end of a Dialogue line is the style; keep the comma count exact. A missing comma shifts every field.

### 6.2 SRT — the portable copy

```
1
00:00:03,200 --> 00:00:06,900
첫 번째 가사의 한 줄
the first line of the lyric
```

Needed even when burning, because platform captions and any later re-edit take SRT, and a burned master without subtitle files cannot be corrected without re-encoding. Keep cue timings identical to the ASS.

SRT carries no styling. Burning from SRT means one style forced onto everything:

```bash
ffmpeg -y -i v1_visual_master.mp4 \
  -vf "subtitles=subs/lyrics.srt:fontsdir=fonts:force_style='FontName=Noto Sans KR,FontSize=34,PrimaryColour=&H00F5F2EA,OutlineColour=&H101C1C1C,BorderStyle=1,Outline=2,Shadow=1,Alignment=2,MarginV=58,MarginL=80,MarginR=80'" \
  -an -c:v libx264 -crf 16 -preset slow -pix_fmt yuv420p -g 24 -movflags +faststart v2_lyric_master.mp4
```

Bilingual burning needs ASS: `force_style` is global and cannot size two languages differently.

## 7. Burning onto v1

### 7.1 Picture only, silent

```bash
ffmpeg -y -i v1_visual_master.mp4 \
  -vf "subtitles=subs/lyrics.ass:fontsdir=fonts" \
  -an -c:v libx264 -crf 16 -preset slow -pix_fmt yuv420p -g 24 -movflags +faststart v2_lyric_master.mp4
```

### 7.2 Picture plus the owner's track

Measure both files first — the picture is never cut down to a shorter track:

```bash
ffprobe -v error -show_entries format=duration -of csv=p=0 audio/track.wav
ffprobe -v error -show_entries format=duration -of csv=p=0 v1_visual_master.mp4
```

```bash
ffmpeg -y -i v1_visual_master.mp4 -i audio/track.wav \
  -vf "subtitles=subs/lyrics.ass:fontsdir=fonts" \
  -map 0:v -map 1:a -c:v libx264 -crf 16 -preset slow -pix_fmt yuv420p \
  -c:a aac -b:a 192k -ar 48000 -t {RUNTIME} -movflags +faststart v2_lyric_master.mp4
```

- The music is always the owner's file. This skill never sources, licenses, or generates a track, and a delivery note never implies the music is cleared by us.
- Reconcile lengths before burning: if the track runs longer than the picture, `-t {RUNTIME}` trims it at the picture's last frame; if it is shorter, the picture still runs its full length and the tail is silent — report the gap in seconds and let the owner decide (shorter edit, re-rendered track, deliberate fade). Do not truncate the film to match the track.
- **Never `-shortest`**: it ends the file at whichever stream is shorter, which is exactly the failure above. `-t` with the v1 duration to the millisecond (`30.000`) is the only trim allowed here.
- Re-encoding at `-crf 16` is one generation; do not chain more passes after this.

On Windows the filter path needs escaping (`C\:/path/lyrics.ass`); forward slashes are safest everywhere.

## 8. Gate

| Check | Pass condition |
|---|---|
| Frame count / duration | identical to v1 (burning text must not change the cut) |
| Resolution / fps / pix_fmt | identical to v1 |
| Audio | present only if a track was supplied; ends where the film ends (or the shortfall reported); not clipped |
| Cue count | matches the lyric sheet, no duplicate or missing line |
| Sync | three anchors per section checked on frames |
| Longest cue | fits the safe zone at both its first and last frame |
| Faces | no cue sitting over an eye line or a mouth |
| End | last cue clears before the final frame |
| Stills | the first frame containing text captured as a PNG for the delivery note |
| Files | `v2_lyric_master.mp4`, `subs/lyrics.ass`, `subs/lyrics.srt` (plus per-language SRTs) |

## 9. Delivery note

```
v2 lyric master — {runtime}s, {fps} fps, {WxH}
Lyrics: {Korean only | English only | Korean + English}
Cues: {n} · first cue {tc} · last cue cleared at {tc}
Audio: {owner's track, {d} s | none — silent}
Not verified / to confirm: {unapproved translation, a line the artist should check, a font fallback}
```

Anything the owner should decide — a translation, a line that does not fit, a cue that lands over a face — belongs in that last line, in plain words. The film is delivered; the remaining choices are theirs.
