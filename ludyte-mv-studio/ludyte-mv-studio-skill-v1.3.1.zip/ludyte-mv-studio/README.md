# Ludyte MV Studio

**v1.3.1 — two masters in one pass, and a board that pays for itself.** When the song has a track and lyrics (an audio file with embedded `USLT` tags counts), the run does not stop at the silent cut: it burns the lyric subtitles and muxes your track straight after the edit, and delivers `v1_visual_master.mp4` **and** `v2_lyric_master.mp4` (plus `subs/lyrics.ass` and `subs/lyrics.srt`) together. Default resolution is still 768p (1366×768 at 16:9, 768×1366 at 9:16) for stills, every generated clip and every master; 1080p and 2K are opt-in upscales.

A Claude skill that directs an AI music video from **lyrics + a few reference images** to a finished, probed master — storyboard, generation batch, edit, crossfades, and burned Korean/English lyric subtitles.

Built for image-to-video workflows where clips come in fixed 5 or 10 second takes (Ludyte, Seedance and similar), and where the film has to land on an exact runtime.

---

## What it does

| Stage | What you get |
|---|---|
| **1. Board** | A storyboard whose cut count comes from the runtime, with a locked style bible, one keyframe still per cut, and a ready-to-paste image-to-video prompt per cut (no lip sync, no on-screen text, one camera move) |
| **2. Batch** | A task manifest that tracks one generation per cut, downloads only finished originals, probes each file, and refuses re-rolls, resubmits, purchases and duplicate billing |
| **3. Visual master** | `v1_visual_master.mp4` — exact runtime and frame count at 768p, silent, assembled with hard cuts, match cuts or `xfade` crossfades with the timeline compensated for overlap |
| **4. Lyric master** | `v2_lyric_master.mp4` — the v1 picture with Korean, English or bilingual lyric subtitles burned in, plus `.ass` and `.srt` files. **Runs immediately after stage 3 in the same pass whenever a track or lyrics were supplied** |

The skill is opinionated about three things: runtime is arithmetic on frames, a generation task is money already spent, and nothing is reported as finished until the file itself has been probed.

## Two masters, one pass

A lyric film has two deliverables, and they are cut from the same edit — so the skill produces both before it reports:

| File | Content | Audio |
|---|---|---|
| `v1_visual_master.mp4` | picture only, no text — the edit that gets approved, and the clean master | none, silent by design |
| `v2_lyric_master.mp4` | v1 with the lyric subtitles burned on | the owner's own track |
| `subs/lyrics.ass` · `subs/lyrics.srt` | the styled source and the portable copy, identical timings | — |

So a request like "cut the clips together and add the lyrics" is one run, not two: stage 3 renders and probes the silent master, stage 4 burns onto that same file and muxes the track, and both files arrive together, with `lyrics.ass` and `lyrics.srt` beside them so a later correction does not need a re-render from the clips. The run stops at v1 only when a silent-only delivery was asked for. Stage 4 costs no generation credits — it is two ffmpeg passes over a file already on disk.

## Resolution: 768p by default

A 2K or 1080p generation tier is slower to queue and costs more per task, and a 2K master cannot show detail the clips never had. So the skill fixes **768p** as the default for everything that costs money or that the picture is judged on:

| Tier | 16:9 | 9:16 | Used for |
|---|---|---|---|
| **768p (default)** | **1366×768** | **768×1366** | keyframe stills, every generated clip, the run lock, `v1` and `v2` masters |
| 1080p (upscale) | 1920×1080 | 1080×1920 | only when you ask for a 1080p delivery; labelled upscaled |
| 2K (upscale) | 2560×1440 | 1440×2560 | only when you ask for a 2K delivery; labelled upscaled |

The master renders at the tier the clips were generated at. An upscale is a separate file rendered on request, kept beside the 768p master and named as an upscale in the report — never described as native 2K. If your platform's own 768p tier returns a different frame (1280×768, 1280×720), the probe decides and the whole film is normalised to that one frame.

## Requirements

| | |
|---|---|
| Claude | any Claude that can run a skill with shell access (Claude Code, or an agent runtime with a filesystem) |
| ffmpeg / ffprobe | 5.1 or newer (`xfade`, `subtitles` with libass) |
| Python 3 | optional — used for the crossfade offset generator and manifest checks |
| A Korean font | an OFL-licensed `.ttf`/`.otf` (Noto Sans KR, Pretendard, SUIT) in `fonts/` for subtitle work, otherwise Korean renders as boxes |
| Accounts | an image model for stills, and Ludyte or another image-to-video service for clips |

```bash
ffmpeg -version | head -1
ffmpeg -hide_banner -filters | grep -E "xfade|subtitles"
```

## Install

**Claude Code, personal:**

```bash
git clone <this-repo> ~/.claude/skills/ludyte-mv-studio
# or: cp -r ludyte-mv-studio ~/.claude/skills/
```

**Claude Code, per project:**

```bash
mkdir -p .claude/skills && cp -r ludyte-mv-studio .claude/skills/
```

**As an uploaded skill:** zip the folder (with `ludyte-mv-studio/` as the root) and upload it in the skill settings of your Claude account.

Check it loaded: ask "what does the ludyte-mv-studio skill do?" — the answer should describe the four stages.

## Folder layout

```
ludyte-mv-studio/
├── SKILL.md                            # the skill: contract, 4 stages, gates, hard rules
├── README.md
├── README.ko.md
└── references/
    ├── storyboard-prompt-guide.md      # lyric segmentation, 10 beats, prompt formula, camera vocabulary
    ├── batch-task-manifest.md          # TASKS.md schema, states, duplicate-billing guards
    ├── video-mastering-spec.md         # frame math, ffmpeg, crossfades, 768p default and upscale tiers, QC
    ├── lyric-subtitle-spec.md          # SRT/ASS, bilingual layout, safe zones, burning, v2
    ├── h3-skillpack.md                 # MiniMax H3 native structure: modes, fields, labels, speaker IDs, sound, performance cuts
    └── mv-prompt-pack.md               # 48 ready shot prompts: openings, neon, action, drive, rain, objects, endings, performance
```

## Two ways to write the prompt

The skill writes prompts in its own house formula (subject lock → mouth-closed action → camera → tone → constraint), which works on any image-to-video service.

If the engine is **MiniMax H3** (or a platform built on it), the same thinking is re-addressed in H3's native structure before sending: a mode (T2VA / I2VA / FL2VA / L2VA / Ref2VA), an alignment sentence, then `integrated_multimodal_description`, `overall_soundscape` and `non_diegetic_music` — or the six reference-mode sections — with cut timecodes, `(S1)` speaker IDs and the camera phrase written inside the sentence. `references/h3-skillpack.md` is the full specification and the line-by-line mapping; §7 of it is the one branch that matters for a music video: a **no-lip-sync cut** (default, mouth closed, no lyric anywhere) versus a **performance cut** (a singing mouth, one sung line inside `<d>[language] …</d>`, a clean lead vocal stem attached — never a full mix).

`references/mv-prompt-pack.md` is a library of 48 fill-in-the-placeholder shots across ten categories, each already limited to one action and one camera move, tagged `no-lip`, `perf`, `insert` or `face`.

## Use

Work in one project folder; the skill writes only inside it.

```
{project_dir}/
├── PRODUCTION_{T}s.md        # approved timeline: cut order, seconds, transitions
├── LUDYTE_VIDEO_TASKS.md     # task manifest (stage 2)
├── stills/                   # S01_{SHOT}.png … keyframes
├── raw/                      # downloaded originals, never re-encoded
├── out/                      # tasks.txt log, segments, v1 and v2 masters
├── subs/                     # lyrics.ass, lyrics.srt, per-language sheets
├── fonts/                    # the Korean font used for burning
└── audio/                    # the owner's own track (never sourced by the skill)
```

### 1 · Board

> "Here are the lyrics and a photo of the singer. Make a storyboard for a 30-second MV, 16:9, cinematic live action, no lip sync. Give me the keyframe prompt for each cut and the video prompt."

You get the style bible, six cut cards with stills between them (a 30 s film at the 5 s tier), and prompts. Approve or change the board here — it is free.

### 2 · Generate

> "Generate all six cuts at 768p, 16:9, 5 seconds each. Track them in the manifest and tell me when they're done."

The skill registers one task per cut, records each id before anything else, polls at a low cadence, downloads only finished originals, and reports a failure instead of retrying it.

### 3 · Edit

> "Cut the clips to exactly 30 seconds, hard cuts on the beats, a 0.25-second crossfade into the chorus and after the bridge. Silent master."

You get `v1_visual_master.mp4` plus a report: frames, fps, resolution, which cut was upscaled, which fault is visible where. If you want a 1080p or 2K copy of the same edit, ask there — it is rendered as a separate labelled upscale, not as the master.

If you handed over the song and its lyrics at the start, the run does not stop here — it goes straight on to stage 4 and hands you both masters.

### 4 · Lyrics

> "Burn the Korean lyrics on top and the English translation beneath them at a smaller size, 9:16 safe zone, with my track."

You get `v2_lyric_master.mp4`, `subs/lyrics.ass`, `subs/lyrics.srt`, and a note on anything left to confirm (an unapproved translation, a line that does not fit).

> "Cut it together and put the lyrics on — one go, please."

That is the default: `v1_visual_master.mp4` and `v2_lyric_master.mp4` from the same edit, in the same run, with the subtitle files.

## Example prompts

| Say | Get |
|---|---|
| "Storyboard this song, 16:9, cinematic" | board + stills + prompts, with the cut count taken from the runtime |
| "Rewrite cut 08 as a handheld close-up, no face" | one cut revised, nothing generated |
| "Which of these cuts are worth regenerating?" | an honest list with the fault in each — the decision stays with you |
| "Assemble at 24 fps, 45 seconds, crossfades 0.3 s on the four joins that change location" | compensated timeline + xfade graph + exact frame count |
| "Bilingual lyrics, Korean large, English small, clear of TikTok's bottom UI" | timed `.ass` with per-language styles and a 9:16 safe zone |
| "Give me an SRT I can upload as captions instead of burning" | `lyrics.srt` with identical timings |
| "Cut it together and do the subtitles in one go" | `v1` + `v2_lyric_master` + `lyrics.ass`/`lyrics.srt` from one run, both probed |
| "Write this cut in H3's structured format" | the same shot re-addressed as mode + alignment line + three fields, ready to paste into the engine |
| "Give me five opening shots to choose from" | five prompts from the pack, each with shot size, camera move, light and tag |

## What it will not do

- Buy credits, upgrade a plan, or start a second account to finish a film.
- Re-roll, resubmit or regenerate a cut on its own judgement — it reports the fault and waits for you.
- Quote lyrics in a video prompt, request lip sync, or accept on-screen text unless asked. A performance cut is the exception the skill allows only on request: one sung line in `<d>`, a lead vocal stem, never a full mix.
- Call an upscaled clip native 2K, a silent master a mix, or an unverified cut a pass.
- Generate above 768p on its own judgement. A higher tier is slower and dearer, so it waits for you to ask.
- Source, license or generate music. The track is always yours.

## Customising

Defaults live in `SKILL.md §1.1` (aspect, resolution, look, clip length, language) and in the style bible work. Change them at the top of a project, not mid-run: settings drift is what makes cuts unmatchable.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Korean subtitles render as boxes | libass fell back to a font without Korean glyphs | put the `.ttf` in `fonts/` and pass `:fontsdir=fonts` |
| `Offset out of range` from `xfade` | the offset exceeds the accumulated input | recompute with the frame formula in `video-mastering-spec.md §5.3` |
| A one-frame hitch at every fade | mixed fps or VFR sources | normalise with `fps=` before `xfade`, encode with `-fps_mode cfr` |
| Master is 719 frames instead of 720 | a cut rounded down | fix the cut frames, not the last clip |
| Audio in the master | an encode without `-an` | re-encode from the normalised segments |
| Subtitles sit under the app's UI | 16:9 safe zone used on a 9:16 film | bottom margin ≈17 % of height for vertical |
| Subtitles cover a third of the picture | 2K type sizes used on a 768p master | 38–42 px Korean at 1366×768, or scale the ASS `PlayRes` with the frame |

## Version history

| Version | Change |
|---|---|
| 1.3.1 | Cut count derived from the runtime (a 30 s film is 4–6 cuts, not 10); one clip-length rule per engine; performance cuts sent as Ref2VA with one stem per singing voice; `-shortest` removed from the v2 mux so the track never shortens the picture; per-join crossfade compensation; runtime notes for sandboxed and phone-only setups; description cut to the 1,024-character skill limit |
| 1.3.0 | Stage 4 folded into the same pass — subtitles burned and the track muxed whenever they were supplied |
| 1.2.0 | 768p made the default for stills, clips and masters |
| 1.1.0 | H3 skill pack and the 48-prompt library |
| 1.0.0 | Four-stage pipeline, manifest gates, crossfades, lyric subtitles |

## License

Add your own `LICENSE` before publishing — the skill text is yours to license as you choose, and third-party fonts or sample files you add carry their own terms.
