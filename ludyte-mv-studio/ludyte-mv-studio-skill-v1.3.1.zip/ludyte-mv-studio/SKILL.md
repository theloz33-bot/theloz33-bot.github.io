---
name: ludyte-mv-studio
description: Directs an AI music video or short film from lyrics and reference images to a finished, probed file, in four gated stages. Stage 1 boards the song: locked style bible, one keyframe still and one image-to-video prompt per cut, cut count set by the runtime. Stage 2 runs the generation batch against a task manifest and refuses re-rolls, resubmits, purchases and duplicate billing. Stage 3 assembles the clips with ffmpeg into v1_visual_master.mp4 (exact runtime, 768p, silent) with hard cuts, match cuts or xfade crossfades. Stage 4 burns Korean, English or bilingual lyric subtitles and muxes the track into v2_lyric_master.mp4 in the same run. Cuts stay mouth-closed and lip-sync-free unless asked; H3 engines get the native structured prompt. Ships 48 shot prompts. Use when the user brings lyrics, a reference photo or a shot list, or says make an MV, storyboard this song, write the video prompts, H3 prompt, cut the clips together, crossfade, add lyric subtitles, exactly 30 seconds, no lip sync, or a silent master.
---

# Ludyte MV Studio

Directs a music video from lyrics and reference images to a delivered, probed master.

Version 1.3.1.

## The contract: four stages, four gates

| Stage | Input | Output | Gate |
|---|---|---|---|
| 1. Board | lyrics + reference image(s) + target runtime | board (cut count set by the runtime), keyframe stills, per-cut prompts | board approved (or the run is pre-authorized) |
| 2. Batch | approved board + stills | one generated clip per cut, logged in the manifest | every cut DONE and downloaded, or a real blocker reported |
| 3. Visual master | downloaded clips | `v1_visual_master.mp4` — exact runtime, 768p, silent, cut exactly as the timeline says | runtime, frame count, fps, resolution and audio verified on the file |
| 4. Lyric master | v1 + lyric sheet (or embedded USLT) + the user's track | `v2_lyric_master.mp4` — v1 with burned lyric subtitles and the track (**runs immediately after Stage 3 whenever track/lyrics are supplied**) | every cue's timing and safe zone checked on frames, audio verified |

Three things hold the whole job together:

- **Runtime is the spine.** Fix it in stage 1 (seconds *and* frame count) and never let the edit drift from it. Every cut length, every crossfade, every subtitle cue is arithmetic against that number.
- **Generation costs money and time; a cut is a sunk cost.** Each generation task is an order already paid for. Nothing in this skill authorizes buying, re-rolling or resubmitting one — only the person paying can say yes to that.
- **Two masters in one continuous pass.** Build and QC `v1_visual_master.mp4` (silent) first, then immediately proceed to Stage 4 to burn the lyric subtitles and mux the user's track into `v2_lyric_master.mp4` in the same run — deliver both `v1` and `v2` (plus `subs/lyrics.ass` and `subs/lyrics.srt`) together unless the user explicitly asked for a silent-only delivery.

## 0. Read the project before touching anything

Before stage 1, and again at the start of every resumed run:

```bash
ls -la "{project_dir}"
cat "{project_dir}/PRODUCTION_{RUNTIME}s.md" 2>/dev/null   # approved timeline + intent
cat "{project_dir}/LUDYTE_VIDEO_TASKS.md" 2>/dev/null      # existing task manifest
cat "{project_dir}/out/tasks.txt" 2>/dev/null              # append-only download log
ls -la "{project_dir}"/stills "{project_dir}"/out 2>/dev/null
```

A waking run must never duplicate work another run already did: check for tasks already registered, clips already downloaded, and edits already under way before doing anything. If the state is unclear, read again — do not register, submit or regenerate to "start clean".

## Stage 1 — Storyboard and prompt design

Goal: a board that costs nothing to change, because changing it after generation costs credits.

### 1.1 Fix the format

Record these before writing a single shot (defaults below):

| Field | Default | Notes |
|---|---|---|
| Aspect | 16:9 (MV) / 9:16 (reels, shorts) | one aspect for the whole film |
| Resolution | **768p** — 1366×768 (16:9) / 768×1366 (9:16) | the default for stills, every clip and the run lock. 1080p and 2K are opt-in upscales at mastering, never the default: the higher tier buys queue time, not detail the 768p source carries |
| Look | cinematic photoreal | line-art conti or illustration only if asked |
| Clip length | the generation engine's own tiers — 5 s per cut, 10 s for chorus and bridge (Ludyte, Seedance, similar) | H3 accepts 5–15 s in one request; take one tier set for the whole film and never mix two engines' tiers |
| Duration | sum of cut lengths = target runtime | derive the cut count first (1.3), never the other way round |
| Mouth | closed, no lip sync | unless the user explicitly asks for lip sync — then it is a performance cut with its own rules (`references/h3-skillpack.md §7`) |
| Language | stills and prompts in English, review notes in the user's language | |

Resolution is fixed here with the aspect and never raised mid-run. If the platform's own 768p tier returns a different frame (some return 1280×768 or 1280×720), record what the probe says and normalise the whole film to that one frame — a film never mixes frames.

`runtime = Σ cut seconds`, and the frame count must land exactly: see the table in `references/video-mastering-spec.md`. A 30 s film at 24 fps is 720 frames, not "about 30 seconds". If crossfades are planned, their total overlap is part of the arithmetic — see 3.3 before the cut lengths are frozen.

### 1.2 Build the style bible, then lock it

From the reference images, write one block and reuse it verbatim in every still and every prompt:

- **Subject lock** — face shape, hair, eyewear or accessory, skin/hair detail, age. This is the identity that must survive every cut.
- **Wardrobe** — exact garments and colours; one outfit for the film, changed only where the story demands it.
- **World** — 1–2 locations, their materials and light.
- **Palette** — three named colours and where they live (e.g. "amber drink, cyan daylight, warm tungsten lamps").
- **Motif** — the object or frame that repeats, and the rhyme between cut 01 and cut 10.
- **Format** — aspect, clip length, mouth closed, no on-screen text.

If the user gave no reference image, say so plainly: text alone can carry a stylised film, but a human identity cannot be pinned without a photo, and drift between cuts will be visible.

### 1.3 Decide the cut count from the runtime, then map the beats

The runtime decides how many cuts the film can pay for. A generated clip is paid for whether or not its whole length reaches the screen, so a board that generates more seconds than the film runs is money thrown away before a single frame is edited:

```
cuts ≈ round(runtime ÷ 7)      # 30 s → 4, 60 s → 9, 90 s → 13
```

Then make the tiers land exactly: every cut is 5 s or 10 s, and `Σ cuts = runtime` (± the crossfade overlap of 3.3). **A 30 s film cannot carry 10 cuts** — ten 5 s jobs generate 50 s for a 30 s film, and the board has planned the waste before it starts. If the sum cannot land, change the cut count, never the target runtime.

| Runtime | Cuts | Tier mix | What the film can hold |
|---|---|---|---|
| 15 s | 3 | 5+5+5 | hook, one image, one payoff |
| 30 s | 4–6 | 5+5+10+10, or 6×5 | cold open, character lock, chorus, outro |
| 60 s | 9 | 5×6 + 10×3 | verse–chorus–verse–chorus complete |
| 90 s | 13 | 5×8 + 10×5 | the full ten-beat skeleton with room to breathe |

Within that count, map the lyric: one cut per 2–4 lyric lines, never one per line. The ten beats are the full-song structure — a shorter film merges beats rather than shrinking a cut below the tier:

| Cut | Beat | Typical length |
|---|---|---|
| 01 | cold open — world, face withheld | 5–10 s |
| 02 | character lock — first real face | 5 s |
| 03 | verse 1 action | 5 s |
| 04 | first emotional crack | 5 s |
| 05 | pre-chorus build | 5 s |
| 06 | chorus A — hero shot | 5–10 s |
| 07 | verse 2 — contrast, the one allowed place/time jump | 5 s |
| 08 | bridge — closest, roughest shot | 5 s |
| 09 | chorus B — climax | 5–10 s |
| 10 | outro — rhymes visually with 01 | 5–10 s |

| Cuts on the board | Beat map |
|---|---|
| 3 | cold open (01+02) · chorus hero (06+09) · outro (10) |
| 4 | cold open and lock (01+02) · verse (03–05) · chorus hero (06+09) · outro (10) |
| 6 | cold open (01) · lock (02) · verse (03+04) · chorus (05+06) · bridge and final chorus (07–09) · outro (10) |
| 10 | one beat per cut, the skeleton above |

A 10 s job can serve two 5 s cuts only when the action allows it (3.2); otherwise it is one 10 s cut. Full method: `references/storyboard-prompt-guide.md`.

### 1.4 Keyframe stills, one per cut

Generate a still for each cut from the style bible, at the film's aspect and the 768p frame (1366×768 or 768×1366), in the chosen look. Save as `stills/S01_{SHOT}.png`. A still at 768p is the honest preview of the clip: detail the still has and the clip cannot carry is detail the board should not promise.

- Review every still before a single video task is registered — this is the cheap gate. Face consistency, hands, prop shape, stray text or logo fragments, wrong wardrobe all get fixed here.
- No text, logo, or lettering in the stills unless the user handed over a real logo and asked for it; generated lettering reads as broken subtitles once it moves.

### 1.5 Write the video prompt for each cut

The formula, in this order, one paragraph, no sections or markdown inside the prompt:

```
Use the attached keyframe as the first frame. Keep the same {face, hands, wardrobe, prop, set}.
{SHOT SIZE}. Mouth closed and at rest, not singing, not speaking.
{one action the body performs in these N seconds}. {one secondary motion in the world}.
Camera: {one movement}. Do not cut. Do not change lens mid-clip.
{TONE}: {light}, {lens feel}, {texture}.
Ambient only: {diegetic sounds}. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration {N} seconds.
```

Rules that keep generations usable:

- **Never quote lyrics inside the prompt.** Generators read quoted lines as dialogue and animate a mouth. The single exception is a performance cut the user explicitly asked for, where one sung line goes inside the H3 `<d>` block (`references/h3-skillpack.md §7`) — nowhere else.
- **One action, one camera move per clip.** Over-animation is the usual failure; slow beats fast.
- **No mouth traps**: avoid face-on close-ups of the mouth, singing gestures, microphone in frame. Hands, props, over-shoulder, back-of-head, reflection are the safe ways to hold a human presence.
- **State the format in every prompt** (duration, no text, no vocals) — prompts do not inherit from each other.
- The tone line carries the look: lens feel ("85mm", "24mm wide"), light ("high-key daylight plus warm tungsten"), texture ("fine grain").

### 1.6 Write it in the engine's native form when the engine is H3

MiniMax H3 (and platforms fronting it) reads a structured prompt far more accurately than a paragraph: shot changes, camera, mouth shape and sound all follow the format tokens. When that is the engine, take the paragraph written above and re-address it in H3's own structure before sending — mode first (T2VA / I2VA / FL2VA / L2VA / Ref2VA), then the alignment sentence, then `integrated_multimodal_description`, `overall_soundscape`, `non_diegetic_music` (or the six Ref2VA sections), with `[Shot 2] At 00:03.500, ...` cut times, `(S1)` speakers and the camera phrase inside the sentence.

The mapping is one-to-one, so nothing is invented twice:

| House formula line | H3 field |
|---|---|
| subject lock, wardrobe, prop | `<Subject N>` definition, or the opening sentence after `[Shot 1]` |
| keyframe still | `<Picture N>` as first frame (I2VA) or a subject source |
| "Mouth closed and at rest" | no `<d>` block, plus the mouth sentence |
| one action, one camera move | one action clause, one camera clause with type / amplitude / speed |
| tone line | the style sentence |
| ambient only, no vocals | `overall_soundscape:` written out, `non_diegetic_music: N/A` |
| duration | request field, and a last cut time under it |

Aspect ratio, duration and audio policy are request parameters — keep them out of the prompt body and make them match it. Two lines of the §1.5 formula therefore do not survive the conversion: `Duration N seconds.` becomes the request field plus a closing cut time under it, and `Ambient only … No vocals, no music` becomes `overall_soundscape:` written out with `non_diegetic_music: N/A`. A silent cut is not guaranteed by text: send both sound fields as `N/A` **and** the no-audio policy flag.

If the user already runs a prompt-only H3 skill, let that skill own the cut prompts and keep this one on the pipeline — board, batch, edit, subtitles, delivery. Two skills writing the same prompt is how the versions drift apart, and only one of them can be right at a time.

Full specification: `references/h3-skillpack.md`. Ready-made shots in both forms: `references/mv-prompt-pack.md`.

### 1.7 Deliver the board

Per cut: title, role, the lyric lines it covers (as reference for the human, never for the prompt), a one-line direction note, a continuity note, the keyframe still, and the prompt in a code block. **Paste each still between the cut cards**, not collected at the bottom — the board is read as a sequence.

Close with: what repeats across the film, which cuts are optional to re-do, and the exact runtime and frame count the master will be cut to.

## Stage 2 — Batch generation and manifest tracking

Goal: get one good clip per cut without spending twice for the same cut.

The manifest is the single source of truth. Format, state machine and example rows: `references/batch-task-manifest.md`.

### 2.1 Register once

- One task per cut. Before submitting, check the manifest for an existing task id on that cut — a QUEUED, RUNNING or DONE cut is never submitted again.
- Write the task id and URL into the manifest **immediately after** the platform returns it, before the page is closed or the run ends. An untracked task is money with no receipt.
- Lock settings per run and record them: model, resolution tier (**768p unless the owner asked for more**), aspect, duration, count, quality tier, prompt form (free paragraph or H3 native). Changing any of them mid-run makes the cuts unmatchable and the comparison meaningless.
- Mark each cut `no-lip` or `performance` in the manifest. A performance cut carries the sung line in its prompt and needs a lead vocal stem attached; a no-lip cut must arrive silent. Stage 3 uses that flag to decide which clips keep their audio and which are muted.

### 2.2 Watch at a low cadence

- Poll on a schedule measured in tens of minutes, not seconds. No idle waiting, no tight loops.
- If nothing changed, stay quiet and let the next scheduled check handle it. A run that reports "still running" every cycle is noise.
- Inspect the project's existing outputs before each check so a wake never re-downloads or re-reviews what is already on disk.

### 2.3 Download only what is done

- Download the **original** file through the platform's normal Download control into `raw/S{NN}_{SHOT}.{originalext}`. Preserve the extension; never re-encode over the source, never overwrite a source that is already there.
- Record the download in the append-only log (`out/tasks.txt`): cut, task id, path, probed resolution, duration.
- Probe each file on arrival (pixels, fps, duration, audio stream). Trust the probe, not the settings page.

### 2.4 Gated actions

| Action | Allowed without asking |
|---|---|
| inspect project, tasks, outputs, settings | yes |
| register one task per cut when the run was authorized to generate | yes |
| download a DONE original | yes |
| append to the log, write probe results | yes |
| re-roll, regenerate or resubmit a failed or ugly cut | **no** — report it and stop |
| buy credits, upgrade, subscribe, add seats | **no** |
| cancel an in-flight job | **no** |
| delete tasks, or overwrite files marked PASS / FAIL / lowres | **no** |
| change model, resolution, aspect or duration mid-run | **no** |

Report a failure once, with what the platform actually shows, and wait for the person paying to decide. A deadline watch, if one was set, reports the real state once at expiry and is then deleted — it never triggers an automatic regeneration.

## Stage 3 — Assembly into the v1 visual master

Goal: the exact runtime, the intended order, the intended transitions, no generated audio, and numbers you can prove.

Full specification, recipes and QC thresholds: `references/video-mastering-spec.md`.

### 3.1 Lay the timeline

Write the timeline from the approved production document — cut order, in/out, seconds, transition. The edit serves that intent; it does not get to invent a shorter film because a clip came out weak.

### 3.2 Normalise, then cut by frame count

Every segment to one resolution, one fps, SAR 1:1, `yuv420p`, and a fixed frame count:

```bash
ffmpeg -y -i "raw/S01_{SHOT}.mp4" -an \
  -vf "scale=1366:-2:flags=lanczos,fps=24,setsar=1,format=yuv420p" \
  -frames:v 120 -c:v libx264 -crf 14 -preset slow seg_01.mp4
```

If a source is short, extend it by holding its last frame (`tpad=stop_mode=clone`) — never by slowing it down, which changes the cut's rhythm. If a source is long, take the frames you need; a 10 s job can serve two 5 s cuts only if the action allows it.

### 3.3 Choose transitions, and pay for the overlap

Three options, in order of how often they should be used:

| Transition | When | Cost to the timeline |
|---|---|---|
| **Hard cut** | default, and always on a match cut | none |
| **Crossfade** (`xfade`, 0.2–0.5 s) | between shots in different places or times, between verse and chorus, after the bridge | shortens the film by the fade length per join |
| **Fade through black** (`fadeblack`, 0.3–0.6 s) | section break, or an ending | shortens the film by the fade length; also costs rhythm |

A crossfade overlaps two clips, so an N-cut film on D-second fades is `Σ cuts − (N−1)·D` long. Compensate **before** rendering by adding the overlap back to the cut lengths: to land on T seconds, `Σ cuts = T + (N−1)·D`. Never stretch the last clip to hide the shortfall, and never let the fade eat a match cut — a dissolve on a match destroys the match.

Frame-exact form: render fades on integer frame counts (`0.25 s at 24 fps = 6 frames`), compute each join's offset as `offset_k = Σ(first k clip frames) − Σ(fade frames up to and including join k)`, and build the whole chain in one `filter_complex` so no intermediate file rounds timestamps. When only some joins fade — the normal case — the compensation is per join too: `Σ cuts = T + Σ(fade lengths of the joins that actually fade)`. Recipe, mixed-join example and generator script: `references/video-mastering-spec.md §5.2–5.3`.

### 3.4 Assemble, mute, verify

Concat-friendly path (hard cuts only):

```bash
printf "file 'seg_01.mp4'\nfile 'seg_02.mp4'\nfile 'seg_10.mp4'\n" > concat.txt
ffmpeg -y -f concat -safe 0 -i concat.txt -an -c:v libx264 -crf 14 -preset slow \
  -pix_fmt yuv420p -movflags +faststart v1_visual_master.mp4
```

Crossfade path: one `filter_complex` with chained `xfade`, `-an`, `-fps_mode cfr`, `-r 24` (see the spec for the exact graph).

Then verify on the file:

```bash
ffprobe -v error -count_frames -select_streams v:0 \
  -show_entries stream=nb_read_frames,width,height,r_frame_rate,duration -of json v1_visual_master.mp4
ffprobe -v error -select_streams a -show_entries stream=index -of csv=p=0 v1_visual_master.mp4  # must be empty
```

The v1 master is **silent by design**, and whenever the user supplied a track and/or lyrics (including embedded USLT tags), proceed immediately to Stage 4 in the same run to deliver `v2_lyric_master.mp4` (with burned subtitles and audio) alongside `v1_visual_master.mp4`. Only stop at v1 if the user explicitly requested a silent-only delivery.

### 3.5 QC before you say it is done

Check on the file, not in memory: frame count exact, fps as planned, resolution as planned, no audio stream, duration matching frame count ÷ fps, no black or frozen frames at joins, no cut missing, aspect not letterboxed by accident, and every crossfade actually present at its planned frame.

A defect found here is reported honestly — which cut, what the fault is, what is possible without regenerating. A finished-looking report over broken footage is the one failure this skill exists to prevent.

## Stage 4 — Lyric subtitles and the v2 lyric master

Goal: readable, in-sync Korean, English or bilingual lyrics burned onto the finished master, with the originals delivered alongside.

Full specification: `references/lyric-subtitle-spec.md`.

### 4.1 Build the lyric sheet first, then time it

- Start from the user's own lyric text, per language. A translation the user did not write is labelled `translation — not approved` until they say otherwise; never present machine output as the artist's words.
- Time each line to the **sung** line, not to the section. Text comes up ~0.15 s before the first syllable and clears 0.3–0.6 s after the last, or on the next line's entry.
- Minimum 1.2 s per cue, one or two lines per cue, no cue longer than ~6 s. Split a long line rather than shrinking the type.

### 4.2 Lay out for the aspect, not for the editor window

| | 16:9 (1366×768) | 9:16 (768×1366) |
|---|---|---|
| Korean chars/line | ≤ 20 | ≤ 13 |
| English chars/line | ≤ 42 | ≤ 30 |
| Bottom margin | ~7 % of height (≈54 px) | ~17 % of height (≈230 px) |
| Side margin | ~6 % (≈80 px) | ~7 % (≈54 px) |

These are the 768p master's numbers — the same proportions as the larger tiers in `references/lyric-subtitle-spec.md §3–5`, which also carries the 1080p/2K upscale sizes. Work on the master you are actually burning onto: a layout copied from a 2K upscale overflows a 768p frame and covers the picture.

Two lines maximum: sung language on top at full size, translation beneath at ~85 % size and ~90 % opacity. Style: Korean-capable sans (Noto Sans KR / Pretendard), Medium–SemiBold, white with a 2–3 px dark outline plus a soft shadow, optional 40–60 % black box. Square, hard-edged type over skin or bright frames is the usual readability failure.

### 4.3 Burn onto v1, never onto a draft

```bash
ffmpeg -y -i v1_visual_master.mp4 -vf "subtitles=subs/lyrics.ass:fontsdir=fonts" \
  -an -c:v libx264 -crf 16 -preset slow -pix_fmt yuv420p -movflags +faststart v2_lyric_master.mp4
```

With the user's own track, the v2 master is the picture plus that audio — but only after both durations have been read off the files. The picture is never cut down to a shorter track:

```bash
ffprobe -v error -show_entries format=duration -of csv=p=0 audio/track.wav
ffprobe -v error -show_entries format=duration -of csv=p=0 v1_visual_master.mp4
```

- **Track the same length or longer** — mux it, trimmed to the film's exact runtime with `-t`.
- **Track shorter than the film** — burn and mux anyway: the picture runs its full length and the tail is silent. Report the gap in seconds and let the owner decide (a shorter edit, a re-rendered track, a deliberate fade). Do not shorten the film, and do not loop or time-stretch the track on your own.

```bash
ffmpeg -y -i v1_visual_master.mp4 -i audio/track.wav \
  -vf "subtitles=subs/lyrics.ass:fontsdir=fonts" -map 0:v -map 1:a \
  -c:v libx264 -crf 16 -preset slow -pix_fmt yuv420p -c:a aac -b:a 192k \
  -t {RUNTIME} -movflags +faststart v2_lyric_master.mp4
```

`{RUNTIME}` is the v1 duration to the millisecond (`30.000`). Do not use `-shortest`: it cuts the picture to whichever stream ends first, which is the opposite of the rule that the film keeps its runtime.

### 4.4 Gate on frames, not on intent

Burn, then check: frame count and duration unchanged from v1, resolution unchanged, audio stream present only if a track was supplied and ending where the film ends (or the shortfall reported), three cues per section scrubbed against the vocal, no cue crossing the safe zone or a platform's bottom UI, no cue over a face, and the last cue cleared before the film ends.

Deliver all three: `v2_lyric_master.mp4`, `subs/lyrics.ass` (the styled source), `subs/lyrics.srt` (portable, for platform captions). A burned master without the subtitle files cannot be corrected later without re-rendering.

## Hard rules

- No lip sync, no singing mouth, unless explicitly requested.
- No quoted lyrics in prompts — the one exception is a performance cut the user explicitly asked for, where the single sung line goes inside `<d>[language] …</d>` and a lead vocal stem is attached.
- No on-screen text, subtitles or logos unless a real mark or lyric sheet was supplied and asked for.
- Never call an upscaled cut "native" 2K, and never render a bigger master than the generation tier to look more finished. Say the source resolution and that it was upscaled.
- Never deliver a silent master as if it were mixed audio, or a lyric master as if the music were cleared.
- Never invent a QC pass, a missing cut, or footage that failed.
- Never inject a full mix as a vocal reference; a performance cut takes a separated lead vocal stem only.
- Never spend money (credits, plans, upgrades) on your own judgement. Report the amount and wait.
- Never state an external rule, contest criterion or deadline that was not given to you.
- Never let the track's length decide the film's length: no `-shortest`, no trimming the picture to the audio.

## Runtime notes — where the skill is running

The pipeline is files plus ffmpeg, so it needs a runtime that has both. Settle this before promising stages 3 and 4:

| Runtime | What works | What to arrange first |
|---|---|---|
| Agent runtime with a shell and a filesystem (desktop app, CLI) | all four stages | — |
| Chat sandbox with a code sandbox | stages 1 and 2 always; 3–4 when the sandbox has ffmpeg | outbound network is frequently blocked, so the platform cannot be called from inside and a file cannot be pulled from a URL. Have the owner attach the downloaded clips, or use the platform's own download control, then run ffmpeg on the attachments |
| A session that ends with the turn | nothing that waits | polling on a timer dies when the turn ends. Use the platform's own long-job tools (wait-for-jobs, list-runs) if it has them, or hand the check to a schedule outside the session. Never sit in a loop inside the chat |

- **Installing.** Copying into `~/.claude/skills/` is a desktop path. The ZIP upload in the account's skill settings is the route that works from any device those settings open on; if neither is available to the owner, say so plainly instead of guessing.
- **The platform's own tools.** Do not invent an API for the video service. Read the tool names off the running session; where there are none, the browser page is the interface and stage 2 happens there.
- **Aspect by destination.** Choose the frame from where the film is published — 9:16 (768×1366) for short-form vertical delivery, 16:9 (1366×768) for a YouTube or long-form master — and record it in 1.1. A short-form-first artist is usually a 9:16 job.

## Files in this skill

| File | Read it for |
|---|---|
| `references/storyboard-prompt-guide.md` | lyric segmentation, the 10-beat skeleton, style bible, prompt formula, camera vocabulary, worked example |
| `references/batch-task-manifest.md` | manifest schema, state machine, task ids, gating rules, duplicate-billing protection |
| `references/video-mastering-spec.md` | runtime/frame math, ffmpeg recipes, hard cut / match cut / crossfade with offset math, resolution policy (768p default, 1080p/2K upscale option), QC checklist, defect triage |
| `references/lyric-subtitle-spec.md` | SRT/ASS design, bilingual layout, sync tolerance, safe zones, typography, burning, v2 delivery |
| `references/h3-skillpack.md` | MiniMax H3 native prompt structure: modes, alignment lines, three fields, six-section reference mode, labels and retention markers, speaker IDs, sound fields, performance vs no-lip-sync cuts, checklist and failure triage |
| `references/mv-prompt-pack.md` | 48 ready image-to-video shot prompts across ten categories plus six performance variants, each in the house formula with placeholders to fill |
| `README.md` / `README.ko.md` | installation, folder layout, usage, example prompts, troubleshooting (English / Korean) |
