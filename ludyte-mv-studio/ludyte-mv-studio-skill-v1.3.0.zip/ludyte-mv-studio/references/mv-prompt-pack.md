# MV Prompt Pack — 48 copy-paste shots

A working library of image-to-video prompts for music videos, short films and brand cuts: opening, character lock, emotion, neon night, action, drive, rain and snow, silhouette, objects, endings, plus performance variants for a singing cut.

Every prompt is written in the house formula from `SKILL.md §1.5` — subject lock → mouth-closed action → camera → tone → constraint — so it can be pasted over a keyframe still and run without editing. For an engine that wants the structured H3 format instead, see `h3-skillpack.md`: the body maps line by line, and §11 of that file has the conversion table.

## How to use

1. **Fill the placeholders.** `{SUBJECT}` `{WARDROBE}` `{PROP}` `{LOCATION}` `{PALETTE}` `{LIGHT}` `{SOUND}` are replaced from the project's style bible. Reuse the same filled values in every cut — that is what holds the film together.
2. **Keep one action and one camera move.** The prompts are already limited to that. Adding a second action is what makes a 5 s clip morph.
3. **Change the numbers, not the structure.** `5 seconds` and the shot size are the two lines most worth editing. Length must be a tier the platform actually generates.

The pack carries no resolution: aspect, resolution (768p by default — 1366×768 at 16:9, 768×1366 at 9:16) and duration are request fields on the call, not lines in the prompt body.
4. **Nothing quoted.** No lyric, no dialogue, no slogan inside these prompts. A singing mouth or a spoken line is a *performance variant* (§11) and needs the vocal stem.
5. **Delete what does not apply.** If the cut has no prop, drop the prop clause rather than leaving `{PROP}` in the text.

Tag legend:

| Tag | Meaning |
|---|---|
| `no-lip` | mouth closed, no dialogue, safe default for a cut that gets the finished track in the edit |
| `perf` | performance variant — a singing mouth, needs a lead vocal stem, see §11 |
| `insert` | 1–3 s texture shot, cut in between two beats |
| `face` | the subject's face is in frame; verify the identity against cut 02 before generation |

---

## 1 · Cold open (01–04)

### 01 · Still room, one shaft of light
`5 s` · `wide` · `slow push in` · `no-lip` · interior day

```text
Use the attached keyframe as the first frame. Keep the same room, window frame, floor tone and the dust in the air.
Wide shot, empty room, no person in frame.
A curtain lifts once in the draught and settles; dust turns slowly in the shaft of light across the floor.
Camera: slow push in toward the window. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: hard daylight through one window, deep shadow elsewhere, fine grain, 35mm feel.
Ambient only: room tone, a faint street hum outside, the curtain brushing the sill. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 02 · Empty street, before anyone is awake
`5 s` · `wide` · `static` · `no-lip` · exterior dawn

```text
Use the attached keyframe as the first frame. Keep the same street, wet kerb, shutters and sky colour.
Wide shot of an empty street, no person in frame.
A plastic bag tumbles across the road and stops against the kerb; one shutter rattles in the wind.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: blue hour, sodium streetlights still on, thin mist, 28mm feel, light grain.
Ambient only: distant traffic, wind through an alley, a loose shutter. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 03 · Figure at the far end, face withheld
`5 s` · `extreme wide` · `slow track in` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same corridor, overhead lamps and the figure's {WARDROBE}.
Extreme wide shot from behind: a figure stands at the far end of a long corridor, back to camera, face not visible.
The figure shifts weight from one foot to the other; the coat hem moves with it.
Camera: slow track in along the corridor. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: rows of fluorescent lamps, greenish cast, deep falloff at the end, 40mm feel.
Ambient only: lamp buzz, the figure's coat shifting, a door closing somewhere behind. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 04 · Hands opening a curtain
`5 s` · `close` · `static` · `no-lip` · interior morning

```text
Use the attached keyframe as the first frame. Keep the same hands, sleeve cuffs, curtain fabric and window light.
Close shot on two hands at the edge of a curtain, face out of frame.
The fingers find the seam and pull the curtain open a hand's width; light floods across the knuckles and the fabric falls back.
Camera: steady lock-off, focus holding on the hands. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: soft morning light, warm bounce, shallow depth, 85mm feel.
Ambient only: fabric dragging on the rail, a distant bird, room tone. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 2 · Character lock (05–08)

### 05 · First clear face, at rest
`5 s` · `medium close` · `static` · `no-lip` · `face` · interior

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT} face, hair, {WARDROBE}, and the wall behind.
Medium close-up, subject facing the lens but not into it. Mouth closed and at rest, not singing, not speaking.
The subject blinks once and the eyes settle slightly off-centre; a strand of hair moves at the temple.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: soft window light from camera left, gentle falloff, fine grain, 85mm feel.
Ambient only: quiet room tone, one breath. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 06 · Over the shoulder into a mirror
`5 s` · `medium` · `slow orbit` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT}, {WARDROBE}, the mirror and the wash of light on the wall.
Medium shot from behind the subject's shoulder, the reflection carrying the face. Mouth closed and at rest.
The subject raises one hand and touches the collar; the reflection moves a beat behind the hand.
Camera: gentle orbit to the right, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: single tungsten bulb, warm pool of light, cool shadow at the edges, 50mm feel.
Ambient only: fabric at the collar, a tap dripping, room tone. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 07 · Walking toward camera, coat moving
`5 s` · `medium full` · `track in matching pace` · `no-lip` · `face` · exterior

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT}, {WARDROBE}, {PROP} in hand, and the street behind.
Medium full shot, subject walking toward camera. Mouth closed and at rest, not speaking.
The subject walks four steps and slows, one hand adjusting {PROP}; the coat swings with each step.
Camera: smooth track-in matching the pace, then holds as the subject slows. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: overcast daylight, soft contrast, muted {PALETTE}, 50mm feel.
Ambient only: footsteps on pavement, coat fabric, distant traffic. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 08 · Profile in a doorway
`5 s` · `close profile` · `slow push in` · `no-lip` · `face` · interior

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT} profile, {WARDROBE}, door frame and hallway light.
Close profile shot. Mouth closed and at rest, not singing, not speaking.
The subject turns the head a few degrees toward the light and holds; an eyelash moves, the jaw stays still.
Camera: slow push in, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: hard edge light from the hallway, deep shadow on the near side, 100mm feel.
Ambient only: hallway hum, a distant door latch. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 3 · Emotional detail (09–12)

### 09 · Hands worrying a sleeve
`5 s` · `close` · `static` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same hands, {WARDROBE} cuff, and the surface they rest on.
Close shot on hands only, face out of frame.
The thumb works at a loose thread at the cuff, pulling it, then smoothing the fabric flat twice.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: low warm lamp light, shallow depth, visible skin texture, 85mm feel.
Ambient only: fabric rasp, a clock in another room. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 10 · A phone face-down on the bed
`5 s` · `top down` · `static` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same bed sheet, the phone, its case colour and the light falling across the covers.
Top-down close shot, no person in frame.
The phone vibrates twice against the sheet and the screen glow leaks around its edge; the sheet creases where it shifts.
Camera: steady lock-off from directly above. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: late afternoon window light, warm and falling, soft shadow, 50mm feel.
Ambient only: the buzz of the phone against fabric, a neighbour's muffled voice through the wall. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 11 · Reflection in a dark window
`5 s` · `medium close` · `slow push in` · `no-lip` · night

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT} reflection, the window frame, and the city lights beyond.
Medium close-up of the reflection in a dark window, the real subject out of frame. Mouth closed and at rest.
The reflection looks down and away; a light out in the street pulses once across the glass.
Camera: slow push in toward the glass, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: mixed city light, cold glass reflection, soft grain, 75mm feel.
Ambient only: room tone, traffic rising and falling outside. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 12 · Breath fogging cold air
`5 s` · `close` · `static` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT} lower face, scarf, and the dark background.
Close shot framed on the lower face and scarf, mouth closed. Mouth closed and at rest, not speaking.
One slow exhale clouds in the cold air and dissolves; the scarf fibres lift at the edge.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: cold practical light from one side, blue shadows, breath visible, 100mm feel.
Ambient only: one long exhale, a distant car passing. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 4 · Neon night (13–16)

### 13 · Alley of signs
`5 s` · `wide` · `slow truck right` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same alley, cables overhead, sign colours and wet ground.
Wide shot, no person in frame.
Steam rises from a grate and crosses the signs; a neon tube stutters once and steadies.
Camera: truck right with small amplitude at slow speed, revealing more of the alley. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: magenta and cyan neon, wet asphalt reflections, anamorphic flare, 32mm feel.
Ambient only: steam hiss, water dripping into a drain, a scooter passing far off. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 14 · Crossing under the signs
`5 s` · `medium full` · `track left` · `no-lip` · `face` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT}, {WARDROBE}, the crossing and the sign reflections on the road.
Medium full shot, subject walking left to right across the frame. Mouth closed and at rest, not speaking.
The subject crosses in six steps, {PROP} swinging at the side; neon light slides across the face and coat as they pass each sign.
Camera: smooth track left to right, matching the pace. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: magenta–cyan mix, wet road highlights, shallow depth, 40mm feel.
Ambient only: footsteps in shallow water, a crossing signal ticking, distant traffic. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 15 · Night market colour
`5 s` · `medium` · `slow push in` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same stall, awning, hanging bulbs and the colour of the produce.
Medium shot into a night-market stall, the vendor's hands working, no face in frame.
The vendor's hands turn a ladle through a pot; steam rolls up through the bulbs and the awning sags with the heat.
Camera: slow push in toward the pot with small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: tungsten bulbs overhead, warm skin tones, rich reds and oranges, 50mm feel.
Ambient only: bubbling liquid, a ladle against metal, a crowd murmur off screen. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 16 · Rooftop over the city
`5 s` · `wide` · `slow rise` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same rooftop parapet, water tank, laundry line and skyline distance.
Wide shot from the rooftop, no person in frame.
A laundry line lifts and snaps in the wind; one window in the distance switches off.
Camera: slow rise with small amplitude, revealing more skyline. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: cool city glow, scattered windows, sodium haze, 24mm feel, light grain.
Ambient only: wind over concrete, fabric snapping, the city humming below. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 5 · Action (17–20)

### 17 · Breaking into a sprint
`5 s` · `medium full` · `track with subject` · `no-lip` · exterior day

```text
Use the attached keyframe as the first frame. Keep the same {SUBJECT}, {WARDROBE}, shoes and the ground texture.
Medium full shot, subject starting from a stand and breaking into a run away from camera. Mouth closed, not shouting.
The first step lands hard, the body drops and drives forward; arms pump twice as the coat streams behind.
Camera: tracking shot behind the subject, matching the pace. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: overcast daylight, desaturated {PALETTE}, motion blur on the limbs, 35mm feel.
Ambient only: two scuffing footfalls, fabric snapping, wind. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 18 · Jump across a gap
`5 s` · `wide` · `static, pan right` · `no-lip` · exterior day

```text
Use the attached keyframe as the first frame. Keep the same two rooftops, parapet edges and the distance between them.
Wide shot on the gap between two rooftops, subject entering from the left. Mouth closed, not shouting.
The subject sprints in from frame left, plants one foot on the parapet and clears the gap, landing low and rolling to one knee.
Camera: steady lock-off, then pan right with large amplitude at fast speed to follow the landing. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: hard afternoon sun, long shadows on concrete, dust on impact, 24mm feel.
Ambient only: a sharp foot plant, air rushing, a heavy landing on gravel. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 19 · Slipping a punch, close quarters
`5 s` · `medium close` · `handheld follow` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same two figures' wardrobe, the room and the light from one side.
Medium close shot on the two figures, faces partly out of frame, mouth closed.
The near figure drops a shoulder and turns away from the incoming arm; the fabric of the sleeve snaps with the turn.
Camera: subtle handheld follow, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: single side light, deep shadow on the far wall, sweat sheen, 50mm feel.
Ambient only: cloth snapping, a sharp exhale, a shoe pivoting on the floor. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 20 · Throttle and release
`5 s` · `close` · `static` · `no-lip` · exterior dusk

```text
Use the attached keyframe as the first frame. Keep the same glove, throttle grip, handlebar, and the tank colour.
Close shot on a gloved hand on the throttle, rider's body out of frame above.
The wrist rolls the throttle open, the cable tightens, and the hand holds as the frame vibrates with the engine.
Camera: steady lock-off with a slight shake, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: dusk backlight, warm rim on the glove, shallow depth, 85mm feel.
Ambient only: engine rising through the revs, chain whine, wind. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 6 · Drive (21–24)

### 21 · Windscreen in rain
`5 s` · `medium` · `static` · `no-lip` · interior night

```text
Use the attached keyframe as the first frame. Keep the same dashboard, windscreen angle and the colour of the traffic outside.
Medium shot from the passenger seat toward the driver's side, mouth not in frame.
Wipers sweep twice; rain beads run sideways as the car pulls forward and the lights outside smear.
Camera: steady lock-off inside the car, no hand-held drift. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: sodium streetlights through rain, cold dashboard glow, 32mm feel.
Ambient only: rain on the roof, wipers dragging, engine at low revs. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 22 · Hand out of the window
`5 s` · `close` · `static` · `no-lip` · exterior day

```text
Use the attached keyframe as the first frame. Keep the same {WARDROBE} sleeve, hand and the blur of the road behind.
Close shot on a hand held out of a moving car window, faces out of frame.
The fingers open and ride the air, the sleeve cuff whipping back; the background streaks past.
Camera: steady lock-off on the hand. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: low sun behind the car, warm flare, motion blur in the background, 50mm feel.
Ambient only: wind roar, fabric snapping, tyres on asphalt. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 23 · Rear-view mirror, eyes only
`5 s` · `close` · `slow push in` · `no-lip` · interior night

```text
Use the attached keyframe as the first frame. Keep the same mirror, its frame, and the passing lights reflected in it.
Close shot on a rear-view mirror holding the subject's eyes and brow, lower face out of frame.
The eyes lift to the mirror and hold; a streetlight passes behind and slides across the glass.
Camera: slow push in toward the mirror, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: passing sodium light, cool interior shadow, 75mm feel, fine grain.
Ambient only: road noise, an indicator ticking, breathing held low. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 24 · Tunnel lights strobing
`5 s` · `medium` · `static` · `no-lip` · interior night

```text
Use the attached keyframe as the first frame. Keep the same tunnel interior, dashboard, and the subject's silhouette in the passenger seat.
Medium shot across the car at the passenger silhouette, mouth closed.
Tunnel lights pass in even strokes, brightening and dimming the profile; one hand rests on the door trim.
Camera: steady lock-off, small amplitude with the car's motion. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: hard overhead tunnel light, orange–white strobe rhythm, 35mm feel.
Ambient only: tyre hum thickening in the tunnel, wind buffeting. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 7 · Rain and snow (25–28)

### 25 · Umbrellas crossing
`5 s` · `wide` · `static` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same crossing, wet markings, and the colours of the umbrellas.
Wide high shot of a crossing, several umbrellas moving, no face visible.
Umbrellas drift right to left in a loose current; one turns against the flow and stops.
Camera: steady lock-off from above. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: wet asphalt reflecting sign colours, rain streaks in the light, 28mm feel.
Ambient only: rain on nylon, tyres hissing, a crossing signal ticking. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 26 · Snow settling on a shoulder
`5 s` · `close` · `static` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same {WARDROBE} shoulders, scarf and the falling snow.
Close shot on the shoulder and scarf, face out of frame.
Snowflakes land and hold on the wool, one after another; a breath of movement shakes two of them loose.
Camera: steady lock-off, shallow depth. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: cold streetlight above, blue snow highlights, soft falloff, 100mm feel.
Ambient only: snow-muffled street, one distant car, fabric shifting. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 27 · Rain on a window, hand behind glass
`5 s` · `close` · `slow push in` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same window, rain pattern and the hand's position on the glass.
Close shot on a hand pressed flat against a rain-covered window, face out of frame.
Rain runs down in branching lines around the fingers; the hand slides down an inch and stops.
Camera: slow push in toward the glass, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: cold exterior light through rain, soft interior shadow, 85mm feel.
Ambient only: rain against glass, muffled street outside, one breath. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 28 · Puddle breaks under a step
`5 s` · `extreme close` · `static` · `no-lip` · exterior day

```text
Use the attached keyframe as the first frame. Keep the same shoe, puddle edge and the reflected sign above.
Extreme close-up on a puddle, no person in frame above the ankle.
A shoe enters and breaks the surface; the reflection shatters outward and the ripples widen and fade.
Camera: steady lock-off, very shallow depth. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: overcast light, sharp reflection detail, water texture, 100mm feel.
Ambient only: one splash, water settling, distant traffic. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 8 · Silhouette (29–32)

### 29 · Backlit doorway
`5 s` · `full` · `static` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same doorway, the light behind, and the figure's {WARDROBE} shape.
Full shot of a figure standing in an open doorway, backlit, face unreadable. Mouth not visible.
The figure lifts one hand to the frame of the door and holds; the light behind flickers once.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: blown-out backlight, haze, deep silhouette, rim light on the shoulders, 50mm feel.
Ambient only: a low hum from the light, air moving through the doorway. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 30 · Headlights through fog
`5 s` · `wide` · `static` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same road, fog density and the position of the lights.
Wide shot of a road disappearing into fog, no figure in frame.
Two headlights grow slowly out of the fog, the beams widening across the road surface.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: dense fog, hard beam cones, cold blue cast, 35mm feel, light grain.
Ambient only: an engine approaching at low speed, tyres on wet gravel. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 31 · Figure on a fog bridge
`5 s` · `extreme wide` · `slow push in` · `no-lip` · exterior dawn

```text
Use the attached keyframe as the first frame. Keep the same bridge lines, fog and the small figure at the rail.
Extreme wide shot: a small figure stands at the rail of a bridge, back to camera, fog swallowing the far end.
The figure leans on the rail; the fog drifts a metre and thins enough to show two more spans.
Camera: slow push in, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: flat grey dawn, low contrast, heavy atmosphere, 24mm feel.
Ambient only: wind across the bridge, water far below, a cable humming. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 32 · Shadow on a curtain
`5 s` · `medium` · `slow pan right` · `no-lip` · interior night

```text
Use the attached keyframe as the first frame. Keep the same curtain, window and the lamp behind it.
Medium shot on a lit curtain, a person's shadow moving behind it, nobody visible.
The shadow crosses the fabric and pauses; the curtain lifts slightly and the shadow breaks at the edge.
Camera: slow pan right with small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: warm lamp behind the fabric, textured weave, deep room shadow, 50mm feel.
Ambient only: fabric moving, a clock, muffled footsteps behind the curtain. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 9 · Objects and inserts (33–38)

### 33 · Phone screen lighting a hand
`5 s` · `close` · `static` · `insert` · `no-lip` · interior night

```text
Use the attached keyframe as the first frame. Keep the same hand, phone, and the dark surface it rests above.
Close shot on a hand holding a phone, screen facing up, no face in frame.
The screen wakes and brightens the fingers from below; the thumb hovers and then withdraws.
Camera: steady lock-off, very shallow depth. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: screen as the only light source, cold blue fill, warm room shadow behind, 85mm feel.
Ambient only: a notification tone cut short, room tone. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 34 · Steam off a cup
`5 s` · `close` · `static` · `insert` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same cup, saucer, table grain and window light.
Close shot on a cup, no person in frame.
Steam rises in one slow column and bends; the surface of the liquid trembles once and stills.
Camera: steady lock-off, shallow depth. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: backlit window, warm highlight on the ceramic, soft shadow, 100mm feel.
Ambient only: a spoon settling on the saucer, quiet room tone. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 35 · Record turning
`5 s` · `close` · `static` · `insert` · `no-lip` · interior night

```text
Use the attached keyframe as the first frame. Keep the same turntable, record label and the lamp reflection on the platter.
Close shot on a spinning record, no person in frame.
The record turns steadily, the tonearm dipping into a warp; the label blurs into a ring under the lamp.
Camera: steady lock-off from a low angle. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: warm lamp, dust in the air, high-contrast highlights, 85mm feel.
Ambient only: surface noise and a low crackle, the motor humming. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 36 · Shoes on stairs
`5 s` · `low close` · `track down` · `insert` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same shoes, stair treads and the light from below.
Low close shot on feet descending a stairwell, no face in frame.
Two steps land in rhythm, the third pauses on the edge before it drops out of frame.
Camera: track down the stairs at the subject's pace, small amplitude. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: hard light from below, deep shadow above, cool concrete, 35mm feel.
Ambient only: three footfalls, a hand skating on the rail. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 37 · Key turning, lock giving
`5 s` · `extreme close` · `static` · `insert` · `no-lip` · exterior night

```text
Use the attached keyframe as the first frame. Keep the same key, lock plate and the paint scratches around it.
Extreme close-up on a key entering a lock, hand out of frame.
The key slides in, turns a quarter, and the mechanism gives with a small kick against the fingers.
Camera: steady lock-off, very shallow depth. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: one porch light, cold metal highlights, paint texture, 100mm feel.
Ambient only: metal on metal, the bolt sliding home, night air. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 38 · Bare bulb swinging
`5 s` · `medium` · `static` · `insert` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same bulb, flex, ceiling texture and the wall behind.
Medium shot of a bare bulb on a flex, no person in frame.
The bulb swings in a short arc; shadows sweep the wall in time with it and shorten at the centre of the arc.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: single hard bulb, ochre walls, strong moving shadow, 35mm feel.
Ambient only: the flex creaking, a faint electrical buzz. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 10 · Endings (39–42)

### 39 · Empty chair in the same light
`5 s` · `wide` · `slow pull out` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same room, chair, window light and floor marks.
Wide shot of an empty chair in a pool of light, no person in frame.
Dust turns in the light; the curtain edge breathes once against the sill.
Camera: slow pull out, small amplitude, revealing more of the empty room. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: low warm sun, long shadow from the chair, fine grain, 35mm feel.
Ambient only: room tone, the curtain, a street below. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 40 · Walking away until the frame empties
`5 s` · `wide` · `static` · `no-lip` · exterior dusk

```text
Use the attached keyframe as the first frame. Keep the same road, horizon, poles and the {WARDROBE} figure.
Wide shot from behind: the subject walks away down an empty road. Mouth not visible.
The figure walks until it is a small shape, then the road is empty; the coat moves less with each step.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: dusk gradients, cool foreground, warm horizon, 28mm feel.
Ambient only: footsteps thinning, wind in grass, one distant car. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 41 · Door closing, light narrowing
`5 s` · `medium` · `static` · `no-lip` · interior

```text
Use the attached keyframe as the first frame. Keep the same doorway, hallway light and the door's edge.
Medium shot on a door already half closed, no person in frame.
The door swings the last hand's width and latches; the strip of hallway light narrows and disappears.
Camera: steady lock-off. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: bright hallway, dark room, hard edge of light on the floor, 50mm feel.
Ambient only: hinges, the latch, the light switch behind the wall. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

### 42 · Sunrise over the same first frame
`5 s` · `wide` · `slow rise` · `no-lip` · exterior dawn

```text
Use the attached keyframe as the first frame. Keep the same skyline, rooftop edge and the composition of the opening shot.
Wide shot matching the opening frame of the film, no person in frame.
The sky warms from blue to pale gold; one rooftop aerial turns in the wind and settles.
Camera: slow rise with small amplitude, mirroring the opening move. Do not cut. Do not change lens mid-clip.
Cinematic photoreal: pre-dawn blue to warm gold, soft haze, low contrast, 35mm feel.
Ambient only: wind on the rooftop, a distant bird, the city starting up. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

---

## 11 · Performance variants — a singing mouth (43–48)

These are the only prompts in the pack that carry a lyric, inside `<d>`, and they require a **clean lead vocal stem** as the audio reference. Use them for the chorus or a deliberate performance cut, and mark the cut `perf` on the board so stage 3 keeps its audio or mutes it on purpose. Duration and aspect ratio are sent as request fields, not written in the body — resolution is 768p unless the run was authorised higher; 5 s for a chorus line, 10 s where the shot carries two. Fill `{LINE 1}` … `{LINE 6B}` with the sung words verbatim and nothing else. Details and the failure modes: `h3-skillpack.md §7`.

### 43 · Chorus, bust shot, direct to lens
`perf` · `bust` · `slow push in` · `5 s`

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, a bust shot centres {SUBJECT} against {LOCATION}, the lighting and wardrobe of <Picture 1> preserved. A young adult performer with a warm mid-range voice (S1) looks into the lens and sings, <d>[Korean] {LINE 1}</d>. Early in the clip the shoulders settle into the beat and the head tilts slightly; the chest rises on the sustained vowel. As the clip progresses the camera pushes in with small amplitude at slow speed while the eyes stay on the lens. Toward the end the mouth closes on the last syllable and the jaw relaxes as the vocal stem carries the note out.
overall_soundscape: Room tone of {LOCATION} with a faint fabric movement on each beat. No other voice.
non_diegetic_music: N/A
```

### 44 · Chorus, side angle, body in the rhythm
`perf` · `medium` · `track right` · `5 s`

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, a medium shot holds {SUBJECT} from three-quarters left in {LOCATION}, matching the palette and wardrobe of <Picture 1>. A young adult performer with a warm mid-range voice (S1) sings <d>[Korean] {LINE 2}</d> while the shoulders mark the beat. The right hand rises to chest height on the second beat and drops on the fourth. The camera trucks right with small amplitude at slow speed, keeping the face in the same third of the frame. Toward the end the head turns back toward the lens as the line lands.
overall_soundscape: {LOCATION} ambience under the vocal, a single heel strike on the beat.
non_diegetic_music: N/A
```

### 45 · Close-up, whispered line
`perf` · `close` · `static` · `5 s`

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, a close shot frames {SUBJECT} from the brow to the collarbone against {LOCATION}, the light of <Picture 1> unchanged. A young adult performer with a quiet, breathy voice (S1) sings close to the lens, <d>[Korean] {LINE 3}</d>. The delivery stays almost spoken; the lips barely part and the breath is audible on the first syllable. The camera holds a static shot. Toward the end the eyes close once and open again as the note fades.
overall_soundscape: A close breath before the first syllable, room tone of {LOCATION}.
non_diegetic_music: N/A
```

### 46 · Full shot, performance on a stage
`perf` · `full` · `slow orbit` · `10 s`

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, a full shot places {SUBJECT} centre stage in {LOCATION}, with a single overhead source and haze holding the shape of <Picture 1>. A young adult performer with a warm mid-range voice (S1) sings <d>[Korean] {LINE 4}</d> while stepping one pace forward on the first beat. Haze drifts across the source. As the clip progresses the camera orbits to the right with small amplitude at slow speed, keeping the figure centred. Toward the end the arms open on the sustained note and the figure holds the final shape.
overall_soundscape: A stage floor under each step, cloth moving, a faint room reverb.
non_diegetic_music: N/A
```

### 47 · Verse, half-lit face, no dance
`perf` · `medium close` · `static` · `5 s`

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, a medium close-up frames {SUBJECT} against {LOCATION}, one hard side light splitting the face as in <Picture 1>. A young adult performer with a low, cool voice (S1) sings the line <d>[Korean] {LINE 5}</d> without any gesture, the chin level and the jaw relaxed between syllables. The camera holds a static shot. Toward the end the head lowers a fraction and the lit side of the face falls into shadow on the last word.
overall_soundscape: Quiet room tone, one intake of breath.
non_diegetic_music: N/A
```

### 48 · Two-shot, answering lines
`perf` · `medium two-shot` · `static` · `10 s`

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, a medium two-shot frames {SUBJECT A} on the left facing {SUBJECT B} on the right in {LOCATION}, wardrobe and light of <Picture 1> preserved. An adult performer with a warm mid-range voice (S1) sings <d>[Korean] {LINE 6A}</d> while the other listens, mouth closed and body still. [Shot 2] At 00:05.000, the camera cuts to a medium close-up of {SUBJECT B}, who answers in a lower, quieter voice (S2), <d>[Korean] {LINE 6B}</d>, then looks away. The camera holds a static shot to the end.
overall_soundscape: {LOCATION} ambience, one shift of weight on the floor between the lines.
non_diegetic_music: N/A
```

---

## 12 · Pairing a sequence

A film reads as one film when the cuts are chosen as a sequence, not as a collection. Three starting points; replace and reorder freely, keep the runtime arithmetic in `SKILL.md §1.3`.

| Sequence | Cuts |
|---|---|
| **Neon night MV** | 02 empty street → 05 face → 13 alley → 07 walking → 17 sprint → 14 crossing → 33 phone → 21 windscreen → 16 rooftop → 42 sunrise |
| **Quiet emotional short** | 01 room → 05 face → 09 hands → 34 steam → 12 breath → 11 reflection → 27 rain on glass → 40 walking away |
| **Performance chorus** | 04 hands → 05 face → 43 chorus bust → 17 sprint → 46 stage full → 44 side angle → 39 empty chair |

Perfection is not the goal of the first pass: generate the cuts that carry the story, look at them together on the timeline, and only then decide which ones are worth paying to re-roll.
