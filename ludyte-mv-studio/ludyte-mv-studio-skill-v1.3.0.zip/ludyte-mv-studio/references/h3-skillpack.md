# H3 Skill Pack — the native prompt structure for MiniMax H3

Reference for stage 1 (prompt design) and stage 2 (generation) when the video engine is **MiniMax H3**, or a platform that fronts it (Ludyte, Hailuo and similar). H3 was trained on a *structured* prompt format, not on free prose. Shot changes, camera moves, dialogue mouth-shape and sound come out markedly more accurate when the prompt is written in that structure, and noticeably vaguer when it is written as a paragraph.

Sources behind this reference: the official H3 prompt-writing guide shipped with the model (base modes + full-reference mode) and on-platform measurement of H3 performance with an injected vocal stem. Everything here is generalised for reuse; no project, track, artist or account data is included.

---

## 0. What the model wants

| Trait | Consequence for the prompt |
|---|---|
| Video and audio are generated together in one pass, not dubbed afterwards | The mouth, breath and sound of the same beat are decided by one description. Describing the sound is not optional decoration — it steers the face. |
| Trained on one structured clip, roughly 4–15 s | A 30 s film is **two or more prompts**, not one long one. Split at a cut, then cut the clips together on the timeline. |
| Shot list, speaker IDs and camera words are format tokens | Names, order and spelling are not stylistic choices. Do not invent synonyms for `integrated_multimodal_description` or `[Shot 2]`. |
| Aspect ratio, resolution and duration are request parameters | Never write them inside the prompt body. Send them as the call's own fields, matching the prompt — resolution at **768p by default**, raised only when the owner asked for a higher tier. |
| Prompt language is English; quoted content stays in its own language | Write the description in English, keep dialogue, lyrics and on-screen lettering verbatim in the original language, inside their markers. |

Two rules that hold for every mode below:

1. **Only what is visible or audible.** External appearance, position, light, action, state change, sound. No plot summary ("she is sad because he left"), no mood adjectives standing in for description ("cinematic", "beautiful", "emotional").
2. **A cut must carry new information.** Subject, place, state, viewpoint or time. If only the distance or the angle shifts a little, use a camera move inside the shot instead of a cut.

---

## 1. Pick the mode first

The attachments and their assigned reference roles decide the mode. Choose before writing a single line.

| Input | Mode | Structure |
|---|---|---|
| Text only, no reference | **T2VA** | 3 fields |
| One image, role = first frame | **I2VA** | alignment line + 3 fields |
| First frame + last frame | **FL2VA** | alignment line + 3 fields |
| Last frame only | **L2VA** | alignment line + 3 fields |
| Any other reference at all: identity, costume, prop, scene, colour look, motion, camera, storyboard, reference, edit source, voice timbre, audio reuse, background music | **Ref2VA** | 6 sections |

A mixed set (a character sheet *plus* a first frame) is Ref2VA. In that case the first-frame image becomes its own `<Picture N>` item, and the character sheet is the source inside a `<Subject N>` definition.

---

## 2. The base format (T2VA / I2VA / FL2VA / L2VA)

```text
<alignment sentence — I2VA, FL2VA, L2VA only; T2VA has none>

integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

- The alignment sentence is the first line, followed by one blank line.
- The three fields come in that order, one blank line between each.
- `integrated_multimodal_description` holds picture, action, shots, speakers, dialogue, song and in-scene sound in play order.
- `overall_soundscape` is the whole clip's ambience, physical action sound and non-verbal human sound.
- `non_diegetic_music` is score only the audience hears — never something a character hears.

### 2.1 Alignment sentences, verbatim

I2VA — always this exact sentence:

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.
```

FL2VA:

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.
```

L2VA:

```text
How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.
```

`N` is the real last shot number (1 for a single shot). `S.SS` is the clip length to two decimals — 8 s is `8.00`, and it must equal the duration actually requested. Note the source's own inconsistency: the FL2VA sentence writes `Picture 1` / `Picture 2` without angle brackets, while I2VA and L2VA use `<Picture 1>`. Keep each sentence exactly as written above.

### 2.2 Making the keyframe do work

- **I2VA** — start at the image and go forward. The image *is* the 0.00 s frame and belongs to `[Shot 1]`. Name the style, subject, framing and spatial anchors that the image fixes, then the action that follows. State that identity, wardrobe, colour, key prop and their positions hold to the end.
  Flow: *first-frame anchor → action begins → continuous development → result or reaction.*
- **FL2VA** — describe the **path between** the two frames. Do not describe each still separately. How the body moves, how the pose changes, how the object is handled, how framing and light cross over. Default to a single shot so the model can interpolate; multi-shot only when explicitly asked. The last shot must land on the last frame.
  Flow: *state at the first frame → visible intermediate changes → the gap narrowing → state at the last frame.*
- **L2VA** — infer the start and arrive on the image. The image is the final frame of the last shot (not a Shot 1 frame). Work backwards to a plausible earlier state and write the convergence.
  Flow: *plausible earlier state → clear action and transition path → gradual convergence → landing on the final frame.*

---

## 3. `integrated_multimodal_description` — the body

Open with style immediately after `[Shot 1]`. Useful style words: `Cinematic`, `live-action`, `2D-animated`, `3D CG`, `claymation`, `watercolour`, `vintage film`. In keyframe modes the style comes from the reference image; in T2VA from the brief.

```text
[Shot 1] Live-action, cinematic, a medium-wide shot frames ...
```

Timing:

- No timestamp on `[Shot 1]`.
- Later shots start with a cut time on the `MM:SS.mmm` clock, increasing, always inside the clip length:

```text
[Shot 2] At 00:03.500, the camera cuts to ...
```

- Cut phrasing: `the camera cuts to`, `the shot cuts to`, `the shot transitions to`, `the shot changes to`, `the shot switches to`. Cross dissolves, fades and wipes only when the brief asks for them.
- Inside one shot, order time with flow phrases instead of numbers: `Early in the clip`, `As the clip progresses`, `Toward the end`.

### 3.1 Camera vocabulary — three axes

Type of move · amplitude (how much the frame changes) · speed. Add amplitude and speed only when they mean something; medium amplitude at normal speed is usually left out.

| Axis | Term | Meaning |
|---|---|---|
| Type | `Zoom In` / `Zoom Out` | camera fixed, focal length changes |
| Type | `Push In` / `Pull Out` | camera travels forward / back |
| Type | `Pan Left` / `Pan Right` | lens rotates left / right in place |
| Type | `Truck Left` / `Truck Right` | camera slides sideways |
| Type | `Tilt Up` / `Tilt Down` | lens rotates up / down in place |
| Type | `Pedestal Up` / `Pedestal Down` | whole camera rises / drops |
| Type | `Arc Shot` | camera travels on an arc around the subject |
| Type | `Tracking Shot` | camera follows a moving subject |
| Type | `Static Shot` | position and lens both fixed |
| Type | `Shake Slightly` / `Shake Strongly` | weak / strong handheld shake |
| Type | `POV` | the subject's point of view |
| Type | `Roll Clockwise` / `Roll Counterclockwise` | camera rolls about its lens axis |
| Amplitude | `with small amplitude` / `with large amplitude` | small / large change of frame |
| Speed | `at slow speed` / `at fast speed` | slow / fast |

Write it as an action inside the sentence, not as labels stacked at the end:

```text
The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.
The camera pans right with large amplitude at fast speed, revealing the open doorway.
The camera holds a static shot as the runner exits the frame.
```

---

## 4. Speakers, dialogue and song

- Give every entity that speaks, sings or makes an off-screen voice a fixed ID: `(S1)`, `(S2)`. Two speakers together are `(S1,S2)`. The ID survives shot changes. Figures that make no sound get no ID.
- On first appearance, establish the voice: person type, age range, gender, in frame or off, pitch, timbre, pace, accent.
- Put the pointing phrase, the ID, the action and the delivery **outside** `<d>`; inside `<d>` goes only the language tag and the words themselves. Given words are preserved exactly, punctuation included — never translated, never corrected.
- **Off-screen voiceover** uses exactly `says in an off-screen voiceover`, and the sentence right after the `<d>` block must say that the on-screen person's lips stay closed:

```text
The man (S1) says in an off-screen voiceover: <d>[Korean] 그 길이 아직도 기억나.</d> while his lips remain completely closed.
```

- **Dialogue or lyric crossing a cut**: put `<scenetrans>` at the break on both sides and say the audio carries over — `continues seamlessly across the cut`, `continues uninterrupted into the next shot`, `carries over from the previous shot`, `remains audible across the transition`.
- **Words cut off by the end of the clip**: `<cutoff>`.
- **On-screen lettering** — banners, signs, labels, subtitles, neon — goes inside English double quotes, verbatim and untranslated: `A red neon sign reading "영업중" glows above the doorway.`

---

## 5. The two sound fields

`overall_soundscape` — 1–4 English sentences, one paragraph. Whole-clip ambience, physical action sound, non-verbal human sound: wind, rain, traffic, footsteps, fabric, impact, breath, laughter, panting. Never repeat dialogue, lyrics or in-scene music that the body already contains. `N/A` only when the user asks for complete silence.

`non_diegetic_music` — 1–3 English sentences. Instrumentation, tempo, rhythm, dynamic change. No mood words (`sad`, `hopeful`), no explanation of the music's emotional function. Music a character hears — radio, a song, an instrument being played — is an in-scene event and belongs in the body. If there is no score, write `N/A`.

Silence is not guaranteed by text alone: for a truly silent clip, set both sound fields to `N/A` **and** send the audio policy flag (`audio_policy: "no_audio"`).

---

## 6. Full-reference mode (Ref2VA) — six sections

All six sections in this order, all English except quoted content:

| Section | Job |
|---|---|
| `subject_definitions` | what each reference is and what label it carries |
| `summary` | work type, target clip, the main reference relationships |
| `retention_analysis` | how each reference is preserved, transferred or reused |
| `detailed_description` | picture, action, shot, sound, dialogue in play order |
| `overall_soundscape` | ambience and physical sound |
| `non_diegetic_music` | audience-only score |

Write each section as `section_name:` on its own line, content from the next line, one blank line between sections. A label means the same thing in all six sections.

### 6.1 The four labels

| Label | Meaning |
|---|---|
| `<Subject N>` | visible content lifted from a reference asset and reused or modified in the target clip |
| `<Picture N>` | a reference image used as a concrete target frame or a shot-design anchor |
| `<Video N>` | a reference video giving an edit source, a continuation start, or the clip-wide time structure |
| `<Audio N>` | an audio signal copied or referenced |

`<Subject N>` is a *unit of content*, not a file: a person or animal, a place, wardrobe, prop, UI, effect, style, motion, expression, pose. One asset can define several subjects; one subject can be defined by several assets.

```text
<Subject 1> is the young woman in <Picture 1>, with long dark hair, a blue cardigan, and a thin silver necklace.
<Subject 1> is the woman whose appearance comes from <Picture 1> and whose walking motion comes from <Video 1>.
```

A `<Picture N>` gets its own definition line only when the image itself is a first frame, keyframe, last frame or framing anchor. An image that merely carries a character, place, costume or style is cited inside that subject's definition instead.

```text
<Picture 2> is the first frame of [Shot 1], showing a woman seated beside a café window.
```

`<Video N>` covers clip-wide relationships only: editing the source, continuing from its end, borrowing its camera moves, cuts, rhythm or timing. If you reuse the *people or places* in it, that is a `<Subject N>`.

`<Audio N>` is a standalone audio asset or the synchronous track of a reference video, used to copy a signal, reference a score style, reference a voice timbre, reuse source dialogue or effects, or reference tempo. Tie it to a speaker's global ID when it belongs to one:

```text
<Audio 1> is the voice-timbre reference for <Subject 1> (S1).
```

Video and audio are numbered separately (a picture from one film and its sound can be `<Video 1>` and `<Audio 2>`). A reference video having sound does not create an `<Audio N>` — only actually using that sound does.

### 6.2 Role → label

| Platform reference role | In the prompt |
|---|---|
| identity, costume, prop, scene, colour look, typography, reference (image) | source inside a `<Subject N>` definition (`... in <Picture N>`) |
| first frame, last frame, storyboard | its own `<Picture N>` item |
| motion, camera (video) | motion as a `<Subject N>` source, camera/cut/rhythm structure as a `<Video N>` item |
| edit source | `<Video N>` = the source being edited, work type `video editing` |
| voice timbre | `<Audio N>` timbre reference → marker `reference` |
| audio reuse, background music | `<Audio N>` signal reuse → `fully_copy` or `partially_copy` |

Reference IDs are submitted in label order (pictures from 1, videos from 1, audio from 1, counted per kind).

### 6.3 Work types and retention markers

`summary` opens with a bracketed work type; join several with ` + ` and never repeat one type.

| Work type | When |
|---|---|
| `keyframe completion` | an image is a concrete frame anchor (first, key, last) |
| `reference generation` | references only guide character, place, style, motion, camera or storyboard |
| `video editing` | an existing clip is directly modified |
| `video continuation` | new content continues from an existing clip |
| `audio reuse` | the same audio signal is reused whole or in part |
| `audio reference` | the signal is not copied; only style, timbre, dialogue content, texture or tempo is referenced |

`retention_analysis` gets one line per label, using only the markers inside that label's defined role. Newly invented action or background is not a preservation loss. No `(Sx)` in this section.

Visible content: `fully_preserved`, `partially_preserved`, `attribute_transfer` (a trait moves to another identifiable target), `weak_reference` (rough similarity of style, category, framing or mood).

```text
<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved - ...
<Picture 2> ([Shot 1] first frame): fully_preserved - ...
<Video 1> (cut and pacing structure): weak_reference - ...
```

Audio: `fully_copy` (the whole source becomes the whole final track), `partially_copy` (some sections or layers, or mixed in and out), `reference` (timbre, rhythm, style, dialogue content or texture only), `weak_reference` (category or mood only).

### 6.4 `detailed_description` differs from the base body

| Item | Base modes | Ref2VA |
|---|---|---|
| Body field | `integrated_multimodal_description` | `detailed_description` |
| Style sentence | after `[Shot 1]` | **before** `[Shot 1]`, 1–2 English sentences |
| Reference information | no labels | labels inserted at first appearance and wherever the role does work |
| Audio relationship | the clip's own sound | name `<Audio N>` in the shot and say whether it is copied or referenced |

```text
The target video is in a cinematic, literary music-video style with soft lighting and a slightly desaturated colour palette.
[Shot 1] The scene opens in a crowded urban street...
[Shot 2] At 00:09.000, the shot cuts to an extreme close-up...
```

Length: 350–500 English words for a generation task; when the dialogue is dense, fitting the whole dialogue timeline beats the word count. A single shot is not an excuse to write short.

Frame anchors are written as ordinary clauses: `the shot begins from <Picture 1>`, `the shot's keyframe corresponds to <Picture 2>`, `the shot ends on <Picture 3>`.

If a referenced subject speaks, use both labels: `<Subject 2> (S1) turns toward the woman and says, <d>[Korean] ...</d>` (add `off-screen` if the voice is off camera). Assign each `(Sx)` once, in the order the clip actually makes sound, and reuse it. Lyrics or words that exist only inside a reused score do not create a speaker — cite `<Audio N>` as the sound's source:

```text
When <Audio 1> reaches the phrase <d>[Korean] ...</d>, <Subject 1> performs the corresponding hand gesture without becoming a separate speaker source.
```

Reused or re-performed dialogue keeps its original language and punctuation inside `<d>`; an unintelligible stretch is `[unclear]`, never a guess.

---

## 7. The MV decision: performance cut or no-lip-sync cut

This is the branch that matters most for a music video, and the one place where the house rule "never put lyrics in a prompt" narrows.

H3 generates mouth shape from the audio it generates in the same pass, and when a clean **lead vocal stem** is injected it is among the most accurate lip-sync models measured. So a singing mouth is a real option — but it is a *different kind of cut* with different rules, not a default.

| | **No-lip-sync cut** (default) | **Performance cut** (only on request) |
|---|---|---|
| When | The film's audio is the owner's finished track, laid on in the edit | The user explicitly asks for a singing/performance shot, or supplies the vocal stem |
| Body | No `<d>` block at all; no lyrics, quoted or otherwise | One `<d>[language] line</d>` per sung phrase, lyrics verbatim |
| Mouth | `Mouth closed and at rest, not singing, not speaking.`; keep the mouth out of close face-on framing | Mouth performs the line; bust shot to close-up reads best for phonemes, breath and jaw |
| Sound fields | `overall_soundscape:` ambience only; `non_diegetic_music: N/A` | `non_diegetic_music: N/A` still (the track is added later); the vocal is supplied as the audio reference, not described |
| Extra | `audio_policy: "no_audio"` when the cut must arrive truly silent | Audio is a required reference; nothing to add in text |
| Effect on stage 3 | Nothing to strip; the clip arrives silent and is cut to the timeline | Strip the generated audio in stage 3 unless it is the intended vocal |

Rules for a performance cut, in order of what actually breaks:

1. **Inject a clean lead vocal, never a full mix.** Drums, bass and attacks are read as voice and produce flapping or beat-locked over-acting. Separate the vocal first, then re-combine with the instrumental in the edit.
2. **Keep the slice short.** 5–10 s of audio per generation; long durations drift.
3. **Do not paste the whole lyric sheet.** Only the phrase actually sung in that clip, and only inside `<d>`. Delivery direction stays outside.
4. **Choose the frame for the mouth.** Bust shot through close-up. Wide shots lose phoneme accuracy; use a medium/full shot only when body rhythm matters more than the lips — in that case treat it as a no-lip-sync cut.
5. **Give the voice an ID and a timbre** (`(S1)`, age, gender, pitch) so the same voice persists across cuts.
6. **Check the frame's mouth first, not last.** A mouth that starts moving in the second frame never recovers; re-roll is a paid action and belongs to whoever pays.

Mixed films are normal: performance cuts on the chorus, no-lip-sync everywhere else. Decide per cut in the board, and mark each cut `performance` or `no-lip` so stage 3 knows which clips keep their audio and which are muted.

---

## 8. Length and pacing

- A 5–8 s single shot: roughly 120–250 English words in the body. A 10–15 s multi-shot: 250–500. More specific beats shorter, but every sentence must still point at something visible or audible.
- Allowed clip length is 5–15 s (a 30 s clip goes through the platform's timeline feature, if it has one). For a 30 s film, write two 15 s prompts rather than one 30 s prompt.
- Korean dialogue runs about 4–5 syllables per second. When the line is long, cut the line, not the description.

---

## 9. Pre-send checklist

- [ ] The alignment sentence matches the mode, and `S.SS` equals the real requested duration.
- [ ] Field names, order and spelling are exact; one blank line between fields.
- [ ] The last cut time is inside the clip length; shot numbers are consecutive.
- [ ] `<d>` holds only a language tag and the original words; delivery direction sits outside.
- [ ] Every label maps 1:1 to an attachment that was actually uploaded, and no undefined label is used.
- [ ] Neither sound field repeats dialogue or lyrics.
- [ ] Duration and aspect ratio are sent as request fields, matching the prompt; resolution is 768p unless a higher tier was authorised for this run.
- [ ] A silent cut carries `audio_policy: "no_audio"`.
- [ ] For a performance cut: the injected audio is a lead vocal stem, and the cut is marked `performance`.

---

## 10. When the clip comes back wrong

| Symptom | Usual cause | Fix |
|---|---|---|
| Something cut in that was never described, or the wrong shot order | A cut time beyond the clip length, or non-consecutive shot numbers | Correct the timecodes; keep the last one inside the length |
| Over-animated, morphing, extra limbs | Too many actions in one shot | One primary action plus one secondary motion per shot |
| Mouth moving on a cut that should be silent | No mouth rule, face-on close-up, or a stray `says`/lyric in the body | Add the mouth sentence, reframe, remove the quoted line |
| Dialogue squeezed, words swallowed | Too many syllables for the duration | Shorten the line or extend the clip |
| Subject drifts from the keyframe | Description contradicts the keyframe, or an undefined label | Rewrite the opening to match the still; define every label |
| Sound of a full mix bleeding into the voice | Full mix injected instead of a vocal stem | Re-inject a vocal-only stem |

Regeneration discipline: change only what was asked. Do not re-light, re-grade or add "brighter / more cinematic" while fixing something else — each re-roll is paid, and a shot that worked should be left alone.

---

## 11. How this fits the four stages

| Stage 1 output | In H3 native form |
|---|---|
| Style bible subject lock | `<Subject 1>` definition (Ref2VA) or the opening sentence after `[Shot 1]` (keyframe modes) |
| Keyframe still | `<Picture 1>` as first frame → I2VA alignment sentence, or a subject-definition source |
| "Mouth closed, not singing" | No `<d>` block, plus the mouth sentence; performance cuts are the sole exception |
| "One action, one camera move" | One action clause, one camera clause (`The camera pushes in with small amplitude at slow speed toward ...`) |
| Tone line | The style sentence (before `[Shot 1]` in Ref2VA, after it in base modes) |
| "Ambient only, no vocals/music" | `overall_soundscape` written out, `non_diegetic_music: N/A` |
| "No on-screen text" | Nothing in double quotes; if a real sign is wanted, quote it verbatim |
| `Duration N seconds` | Request field, plus a timeline whose last cut time is under N |
| 10-cut board | One prompt per cut in the platform's clip-length tiers; a cut longer than the tier is split, never stretched |

The house formula in `SKILL.md §1.5` still works as the thinking frame — subject lock, action, camera, tone, constraint. This reference is how that thinking is *addressed to H3*, and what changes when a cut genuinely sings.
