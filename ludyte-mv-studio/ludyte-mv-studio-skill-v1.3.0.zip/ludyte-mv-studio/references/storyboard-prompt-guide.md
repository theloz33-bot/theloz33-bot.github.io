# Storyboard and Prompt Guide

Stage 1 of the pipeline: turn lyrics into 10 drama beats, lock a style bible, generate one keyframe still per cut, and write an image-to-video prompt that a generator can follow for five seconds.

---

## 1. Fix the runtime before anything else

The runtime is the number every other decision is measured against. Get it from the track, never from "about a minute".

1. Read the song's structure with timestamps: `[Intro] [Verse 1] [Pre-Chorus] [Chorus] [Post-Chorus] [Verse 2] [Bridge] [Chorus] [Outro]`.
2. Write the seconds of each section beside it. The sections must sum to the track length (minus any tail you intend to cut).
3. Fix the format and the cut length tier: 768p (1366×768 at 16:9, 768×1366 at 9:16) for the stills and every clip, and 5 s, or 10 s where a shot carries a chorus. 768p is the default — a 1080p or 2K tier is the owner's call and belongs to a separate run.
4. Fit 10 cuts to the sections. One cut may cover two short sections (intro + first line of verse 1), and a long chorus may take two cuts of 5 s rather than one of 10 s if the second half needs a new image.
5. Convert to frames: `frames = runtime × fps`. If crossfades are planned, see §2.2 — the cut lengths are longer than the timeline by the overlap.

A cut plan is wrong if `Σ cut lengths ≠ runtime` (before crossfade compensation) or if any cut length is not a tier the platform generates. Fix the plan, not the output.

## 2. Ten beats

### 2.1 The skeleton

| Cut | Dramatic job | What the frame must do | Length |
|---|---|---|---|
| 01 | Cold open | place and mood; the subject is present but the face is withheld | 5–10 s |
| 02 | Character lock | the first clear face, at rest; this frame is the identity reference for the film | 5 s |
| 03 | Verse 1 | a small action that belongs to the world | 5 s |
| 04 | First crack | the emotion leaks — a detail shot, not a performance | 5 s |
| 05 | Pre-chorus | approach: motion builds, but one move only | 5 s |
| 06 | Chorus A | hero shot, wide enough to hold everything that repeats | 5–10 s |
| 07 | Verse 2 | the contrast — different place or time, same wardrobe and identity; the **only** place jump allowed | 5 s |
| 08 | Bridge | closest and roughest; texture over information | 5 s |
| 09 | Chorus B | climax; the camera finally commits to the subject | 5–10 s |
| 10 | Outro | the rhyme with 01: same object or frame, now emptied or changed | 5–10 s |

### 2.2 Crossfade-aware lengths

Decide the transition plan now, because it changes the lengths.

- Hard cut: no length change.
- Crossfade of D seconds on N−1 joins: `Σ cut lengths = runtime + (N−1)·D`.
- Example: 10 cuts, 30 s, a 0.25 s crossfade on all nine joins → the cut lengths would have to sum to 32.25 s. No clean tier does that, and that is the signal: use three to five crossfades and hard cuts on the rest. Five 0.25 s fades add 1.25 s, so the cuts sum to 31.25 s and the fades land the film on 30.000 s.

The rest of this guide assumes hard cuts unless a crossfade is called out on a specific join.

### 2.3 Section mapping that usually works

| Song section | Cuts | Note |
|---|---|---|
| Intro | 01 | no face, or face in shadow |
| Verse 1 | 02–03 | 02 is the lock, 03 is the action |
| Pre-chorus | 04–05 | 04 is the crack, 05 is the build |
| Chorus | 06 | hero, the widest frame in the film |
| Verse 2 / Post-chorus | 07 | the jump; keep the wardrobe |
| Bridge | 08 | tightest frame, handheld allowed |
| Chorus 2 | 09 | the repeat, but closer or higher than 06 |
| Outro | 10 | rhyme with 01 |

## 3. Style bible

Write this once, paste it into every still prompt and reuse its vocabulary in every video prompt. Drift happens when each cut is described from scratch.

```
SUBJECT LOCK: {age range, face shape, hair length and colour, eyewear/accessory, distinguishing mark}
WARDROBE:     {garment, colour, fabric, footwear} — one outfit for the whole film
WORLD:        {location 1} and {location 2}: materials, architecture, time of day
PALETTE:      {colour A} in {where}, {colour B} in {where}, {colour C} in {where}
MOTIF:        {repeating object} — appears in cuts {n, n} and closes the film in cut 10
FORMAT:       {16:9 at 1366×768 | 9:16 at 768×1366}, {5/10} s per cut, mouth closed, no lip sync, no on-screen text
```

Rules of thumb:

- One outfit. A second outfit is a second film unless the story demands the change.
- Two locations maximum. The place jump is cut 07's privilege.
- Three colours maximum; name where each one lives, so the grader (and the model) keeps the palette.
- The motif is what makes the film feel authored: the same glass, stairwell, coat hook, or window, seen three times.

## 4. Stills (keyframes)

One still per cut, generated from the style bible, in the film's look and at the film's aspect and 768p frame (1366×768 or 768×1366). `stills/S{NN}_{SHOT}.png`.

Checks before a still is approved (a bad still becomes a paid bad clip):

- [ ] Same face, hair and accessory as the lock — compare side by side with cut 02, not from memory.
- [ ] Hands and fingers correct; no extra fingers, no melted object.
- [ ] Wardrobe matches the bible exactly.
- [ ] No stray lettering, logo, watermark, or subtitle-like marks. Regenerate rather than accept.
- [ ] Framing leaves room for the camera move planned for that cut.
- [ ] Composition differs from its neighbours: shot size or angle must change across a cut.

## 5. The video prompt formula

```
Use the attached keyframe as the first frame. Keep the same {face, hands, wardrobe, prop, set}.
{SHOT SIZE}. Mouth closed and at rest, not singing, not speaking.
{one action the body performs in these N seconds}. {one secondary motion in the world}.
Camera: {one movement}. Do not cut. Do not change lens mid-clip.
{TONE}: {light}, {lens feel}, {texture}.
Ambient only: {diegetic sounds}. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration {N} seconds.
```

Why each line is there:

| Line | Job | Failure it prevents |
|---|---|---|
| "Use the attached keyframe as the first frame" | anchors identity and composition | the model inventing a new face |
| "Keep the same …" | repeats the lock in the model's own terms | wardrobe and prop drift between cuts |
| Shot size | fixes how much of the subject exists | the model zooming out into a new scene |
| "Mouth closed and at rest" | blocks lip sync at the source | a singing mouth and a broken jawline |
| One action + one secondary motion | gives five seconds something to do | over-animation, morphing, extra limbs |
| Camera: one movement | keeps the frame stable across the join | a move that changes speed mid-clip |
| Tone line | carries light, lens and texture | a flat look that does not cut with its neighbours |
| Ambient only / no vocals | stops generated speech or music | audio you must remove, a mouth that moves |
| No text / subtitles / logo | stops fake lettering | garbled text burned into the picture |
| Duration | pins the clip length | a 4 s or 12 s surprise in a 5 s plan |

### 5.1 The mouth problem

Generators animate mouths by default because faces in training data talk. Defence, in order of reliability:

1. Do not frame the mouth: hands, props, over-shoulder, back of head, reflection, silhouette, wide shot.
2. If the face is in frame, say "mouth closed and at rest, not singing, not speaking" — and keep the shot from being a face-on close-up.
3. Never put lyrics in the prompt, in quotes or otherwise. No "she sings", "lip-syncing", "mouthing the words".
4. Review at the first frames, not the last: a mouth that starts moving in frame 2 will not recover.

### 5.2 Camera vocabulary

One move per clip, and slow it down. In five seconds a camera should travel less than a real camera operator would.

| Move | Phrase to write | Use for |
|---|---|---|
| Push in | "slow dolly-in" | intimacy, a detail becoming the subject |
| Lock off | "steady lock-off" | product, detail, a frame that must simply hold |
| Orbit | "gentle orbit to the right" | a hero shot that needs depth without a cut |
| Lateral track | "smooth lateral track left to right" | place change inside one shot |
| Track in with subject | "smooth track-in matching her pace, then holds" | walking toward camera |
| Handheld follow | "subtle handheld follow" | bridge, documentary roughness |
| Rise / crane | "slow rise" | ending, release |
| Whip pan | "fast whip pan" | almost never — it cannot be matched across a cut |

Speed words that work: slow, steady, gentle, subtle, smooth. Words that break clips: fast, rapid, dynamic, energetic, zoom.

### 5.3 Match cuts across the join

A match cut is a decision made in the board, not in the edit:

- **Movement match** — the subject moves left at the end of cut A and left at the start of cut B, at a similar speed and screen position.
- **Shape match** — a round object fills the same part of the frame in both shots.
- **Eyeline match** — the look direction of the last frame continues into the first frame of the next cut.
- **Sound-off match** — the same gesture (a hand closing, a door) completes across the cut.

Write the intent into both prompts ("moves left out of frame", "enters from the right, moving left") so the cut exists in the footage.

## 6. Worked example (generic)

> Placeholder subject and lyrics — replace with the user's own.

**Style bible**

```
SUBJECT LOCK: late 20s, oval face, chin-length black hair with a blunt fringe, thin silver hoop in the left ear
WARDROBE:     oversized charcoal wool coat, cream knit, black trousers, worn leather boots
WORLD:        a 24-hour laundromat at 3 a.m.; a stairwell with green paint and one bare bulb
PALETTE:      detergent blue in the machines, sodium orange from the street, cream in the knit
MOTIF:        a paper cup going cold — cut 03, cut 08, emptied in cut 10
FORMAT:       16:9 at 1366×768, 5 s per cut, mouth closed, no lip sync, no on-screen text
```

**Cut 03 — Verse 1 (5 s, hard cut in, hard cut out)**

Direction: hands and machine, no face. Continuity: same coat sleeve as cut 02.

```
Use the attached keyframe as the first frame. Keep the same coat sleeve, cuff, paper cup and washing machine.
Medium close-up, hands only. No face in frame.
She sets the paper cup on top of the machine and pushes the door shut with her knee; the drum starts and the coat hem sways.
Camera: slow dolly-in on the door glass. Do not cut. Do not change lens mid-clip.
Cinematic photoreal, cold fluorescent overhead plus sodium orange from the street, fine grain, 50mm feel.
Ambient only: drum tumble, a distant door chime. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

**Cut 08 — Bridge (5 s, crossfade in 0.25 s from cut 07)**

Direction: the closest frame in the film. Continuity: cup is half full, same stairwell as cut 07.

```
Use the attached keyframe as the first frame. Keep the same face, fringe, silver hoop, coat and paper cup.
Extreme close-up on the cup and her hands. Mouth not in frame.
Her thumb presses the lid flat; steam stops; the cup gives slightly under the pressure and holds.
Camera: subtle handheld follow, no cut. Do not change lens mid-clip.
Cinematic photoreal, one bare bulb overhead, deep shadow, 100mm feel.
Ambient only: stairwell hum, a held breath. No vocals, no music, no dialogue.
No on-screen text, no subtitles, no logo, no lyric captions.
Duration 5 seconds.
```

**Close of the board**

Repeats: the paper cup and the coat; blue–orange–cream; cut 01's empty machine rhymes with cut 10's empty drum. Runtime: 50.000 s = 1200 frames at 24 fps with hard cuts only. Four 0.25 s crossfades are planned, so the cut lengths must total 1200 + (4 × 6) = 1224 frames (51.000 s); the fades bring it back to 1200 frames — 50.000 s on the nose.

## 7. Board delivery format

Each cut card, in this order:

1. Heading — `## Cut 0N — {beat} — {5 s}`
2. `Lyric (reference only, not for the prompt)`, then the covered lines as a quote
3. `Direction:` — one line
4. `Continuity:` — what must match, what changes
5. The still, pasted **here**, never collected at the bottom
6. `Prompt:` — the written prompt in its own code block

The board ends with one paragraph: what repeats across the film, which cuts are optional re-dos, the exact runtime and frame count, and the transition plan per join.
